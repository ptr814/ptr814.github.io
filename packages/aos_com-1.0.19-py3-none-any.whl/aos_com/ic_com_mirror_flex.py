# *****************************************************************************
# * Copyright by ams OSRAM AG                                                 *
# * All rights are reserved.                                                  *
# *                                                                           *
# * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
# * THE SOFTWARE.                                                             *
# *                                                                           *
# * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
# * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
# * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
# * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
# * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
# * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
# * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES LOSS OF USE,      *
# * DATA, OR PROFITS OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
# * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
# * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
# * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
# *****************************************************************************
"""
This is test class for communication with ICs. 
This is a more advanced version of the IcComMirror. 
It can do wider addresses for larger address ranges (e.g. 16-bit addressing)
and it can be configured for big or little endian addressing. 
Data is always organised as bytes so it will be written as you transmit it on
I2C/SPI. I.e. first byte goes to the address that was specified, next goes
to address+1, etc.
"""

from aos_com.ic_com import IcCom

class IcComMirrorFlex(IcCom):

    # Version log 
    # 1.0 first working version
    VERSION = 1.0

    def __init__(self, log=False, exception_on_error=True, pattern_start:int=17, pattern_step:int=3, memory_size:int=256, addr_width:int=1, addr_endian='little', spi_cmd=1, spi_dummy_wr=0, spi_dummy_rd=0, spi_dummy=0 ):
        """
        Constructor, default is to not produce exceptions, just log the errors
        Args:
            log (TYPE, optional): Print messages. Defaults to False.
            exception_on_error (TYPE, optional): Raise an exception in error case, if false only log error. Defaults to False.
            pattern_start (int, optional): Start byte to fill the memory that is used as mirror. Defaults to 17.
            pattern_step (int, optional): Value that is added for filling the memory for each byte. Defaults to 0x03.
            memory_size (int, optional): How big the mirror shall be. Defaults to 256. For 16-bit addressing use e.g. 4096.
            addr_width_in_bytes (int, optional): How many bytes to use for addressing. Defaults to 1. With 1 you can address
            up to 256 bytes of memory. If you want to emulate 16-bit addressing use e.g. 4096 for memory size and set this to 2. 
            addr_endian (str, optional): either big or little for address endianess. Defaults to little.
            spi_cmd: how many bytes the command has
            spi_dummy_wr: how many bytes to skip in a write
            spi_dummy_rd: how many bytes to skip in a write-read 
            spi_dummy: how many bytes to skip in a read-only
        """
        super().__init__(log,exception_on_error)
        self._reg_addr = 0
        self.gpio_value = 0                 # default all 0
        self.memory_size = memory_size
        self.addr_width = addr_width
        self.addr_endian = addr_endian
        self._buffer = [0xFF & (pattern_start + pattern_step*x) for x in range(self.memory_size)]     # write some pattern to not just have uninit or all 0s
        self.spi_cmd = spi_cmd  # number command bytes
        self.spi_dummy_wr = spi_dummy_wr
        self.spi_dummy_rd = spi_dummy_rd
        self.spi_dummy = spi_dummy

    def __del__(self):
        """Cleanup."""
        super().__del__()

    def _txFunc(self,tx:list,fn_name) -> int:
        """Function to transmit given bytes """
        status = self._OK
        _addr = 0
        if self.addr_endian == 'big':
            for i in range(self.addr_width):
                _addr = _addr * 256 + tx[i]
        else:    
            for i in range(self.addr_width):
                _addr = _addr *256 + tx[self.addr_width-1-i]
        self._reg_addr = _addr
        assert self._reg_addr < self.memory_size, "{} allows only up to register addr ={} for write".format(fn_name,self.memory_size-1)
        for i in range(self.addr_width,len(tx)):
            self._buffer[self._reg_addr] = tx[i]                      # write to buffer
            self._reg_addr += 1                                             # increment address buffer
            if self._reg_addr >= self.memory_size:
                self._reg_addr = self.memory_size-1                    # FIFO must be last
        self._log(fn_name)
        return status 

    def _rxFunc(self,rx_size:int,fn_name) -> bytearray:
        """Function to receive bytes """
        status = self._OK
        _rx = []
        assert self._reg_addr < self.memory_size, "{} allows only up to register addr {} for read".format(fn_name,self.memory_size-1)
        for i in range(rx_size):
            _rx = _rx + [self._buffer[self._reg_addr]]                       # read from buffer
            self._reg_addr += 1                                             # increment address buffer
            if self._reg_addr >= self.memory_size:
                self._reg_addr = self.memory_size-1                    # FIFO must be last
        self._log(fn_name)
        return bytearray( _rx )

    # -----------------------------------------------------------------------------------        
    # I2C functions ---------------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    def i2cOpen(self, i2c_speed:int=1000000) -> int:
        """Open an I2C interface.        """
        fn_name = "i2cOpen"
        status = self._OK
        self._log(fn_name)
        return status 

    def i2cClose(self) -> int:
        """ Function to close a I2C interface. """
        fn_name = "i2cClose"
        status = self._OK
        self._log(fn_name)
        return status 
            
    def i2cTx(self,devaddr:int,tx:list) -> int:
        """Function to transmit given bytes on I2C """
        return self._txFunc( tx, "i2cTx" )

    def i2cRx(self,devaddr:int,rx_size:int) -> bytearray:
        """Function to receive bytes via I2C. """
        return self._rxFunc(rx_size, "i2cRx")

    def i2cTxRx(self,devaddr:int,tx:list,rx_size:int) -> bytearray:
        """Function to transmit and receive bytes via I2C. """
        self._txFunc( tx, "i2cTxRx")
        return self._rxFunc( rx_size, "i2cTxRx")
    

    # -----------------------------------------------------------------------------------        
    # SPI functions ---------------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    def spiOpen(self, spi_speed:int=10000000, spi_mode:int=3 ) -> int:
        """Open an SPI interface.
        Args:
            spi_speed(int): the Hertz for the SPI bus. Defaults to 10 MHz
            spi_mode(int): 0,1,2,3 == clock phase and clock polarity. Defaults to 3.
        Returns:
            int: status: 0 == ok, else error
        """
        fn_name = "spiOpen"
        status = self._OK
        self._log(fn_name)
        return status 

    def spiClose(self) -> int:
        """ Function to close a SPI interface.
        Returns:
            int: status: 0 == ok, else error
        """
        fn_name = "spiClose"
        status = self._OK
        self._log(fn_name)
        return status 

    def spiRx(self,rx_size:int) -> bytearray:
        """Function to receive the given number of bytes
        Args:
            rx_size(int): The number of bytes to receive.
            lsb_first(bool, optional): Bit order shall be little endian or big endian. The default is False = big endian.
        Returns:
            bytearray: Array of received bytes.
        """
        toRx = rx_size - self.spi_dummy
        _rx = bytearray( [0]*self.spi_dummy ) + self._rxFunc( toRx, "spiRx" )      # read in data and add padding at the front
        return _rx     # return extended array

    def spiTx(self,tx:bytearray) -> int:
        """Function to transmit several bytes via SPI.
        Args:
            tx(list): byte list to transmit.
            lsb_first(bool, optional): If the FTDI should transmit in big-endian or little endian mode. The default is False (=big endian mode).
        Returns:
            int: status: 0 == ok, else error
        """
        addr = tx[self.spi_cmd:self.spi_cmd + self.addr_width]              # cut out address part
        data = tx[self.spi_cmd + self.addr_width + self.spi_dummy_wr :]     # cut out data part
        toTx = addr+data                                                    
        self._txFunc( toTx, "spiTx" )
        return self._OK

    def spiTxRx(self,tx:bytearray,rx_size:int) -> bytearray:
        """Function to transmit and receive bytes. the function will extend the transmit list with 0 to match the receive length 
        if there are more bytes to receive than to transmit. the function will extend the receive bytearray
        with additionally read in bytes if the transmit length is greater than the receive length.
        Args:
            tx(list): list of bytes to transmit.
            rx_size(int): number of bytes to receive.
            lsb_first(bool, optional): If the FTDI should transmit in big-endian or little endian mode. The default is False (=big endian mode).
        Returns:
            bytearray: bytes received from the device.
        """
        padding = self.spi_cmd + self.addr_width + self.spi_dummy_rd
        toTx = tx[self.spi_cmd:self.spi_cmd + self.addr_width]              # cut out address part
        self._txFunc(toTx, "spiTxRx")                                       # setup address only
        data = [0]*(padding)                                                # add padding
        data = bytearray( data) 
        if padding < rx_size:                                               # something to read
            toRx = rx_size - padding                                        
            data = data + self._rxFunc(toRx,"spiTxRx")                      # read bytes
        return data


# this is a test class - usefull for simple test of programs
if __name__ == "__main__":
    com = IcComMirrorFlex(memory_size=4*1024, addr_width=2,addr_endian='big')
    com.i2cOpen()
    com.i2cTx(0x11,[0x1, 0x12,  0x34,0x56,0x78,0x9a])
    com.i2cTx(0x11,[0x1, 0x12])
    assert [0x34,0x56,0x78,0x9a] == list( com.i2cRx(0x11,4) )
    fifo_addr = [(com.memory_size-1)//256, (com.memory_size-1)%256]
    com.i2cTx(0x11,fifo_addr+[1,2,3,4,5,6,7,8])
    assert com._reg_addr == com.memory_size-1, "Addr pointer stays at at {}".format(com.memory_size-1)
    assert com._buffer[com.memory_size-1] == 8, "last written value should be read back"
    assert [8,8,8,8] == list(com.i2cRx(0x11,4)), "Fifo read always same value from last address"
    com.i2cClose()
    

