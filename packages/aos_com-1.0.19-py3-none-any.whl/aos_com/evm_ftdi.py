# *****************************************************************************
# * Copyright by ams OSRAM AG                                                 *
# * All rights are reserved.                                                  *
# *                                                                           *
# * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
# * THE SOFTWARE.                                                             *
# *                                                                           *
# * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
# * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
# * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
# * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
# * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
# * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
# * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES LOSS OF USE,      *
# * DATA, OR PROFITS OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
# * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
# * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
# * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
# *****************************************************************************
"""
"""

from aos_com.ftdi_mpsse import FtdiMpsse
from typing import List

def isAmsEvmFtdiAvailable():
    """Search if there is an EVM FTDI board available. 
       Returns: 
        True - if there is an ams EVM FTDI board 
        False - else
    """
    _expected = b'AMS EVM Serial Board'
    _field_name = "Description"
    _com = FtdiMpsse(log=False)
    if _com:
        _num_devices = _com.getNumChannels()
        for _i in range( _num_devices ):
            _dev_info = _com.getChannelInfo( _i )
            if getattr( _dev_info, _field_name) == _expected:
                return True
    return False            # no ams evm board found 

class EvmFtdi(FtdiMpsse):
    """Support for the ams OSRAM EVM-FTDI-1v0 board """
    
    VERSION = 1.0
    """Version log 
    - 1.0 First working version
    """

    _ENABLE_PIN = 0x2               
    """ I2C ACBUS bit 1 is Enable pin. On EVM-FTDI-01 it is ACBUS bit 1"""
    _INTERRUPT_PIN    = 0x1               
    """ I2C ACBUS bit 1 is Interrupt pin.  On EVM-FTDI-01 it is ACBUS bit 0 """

    def __init__(self,log:bool=False,exception_on_error:bool=True ):
        """The default constructor. It initializes the EVM specific FTDI driver.
        Args:
            log (bool, optional): Enable verbose driver outputs. False per default.
            exception_on_error (bool, optional): Error raises an exception. Defaults to True.
        """
        self.i2c_channel = -1
        super().__init__(log=log, exception_on_error=exception_on_error)
        self.enable_pin = EvmFtdi._ENABLE_PIN
        self.interrupt_pin = EvmFtdi._INTERRUPT_PIN
        self.search() 
                                         
    def search(self, i2c_devicename: List[bytes] = [b'AMS EVM Serial Board'],
                     i2c_ftdi_channel:int=-1, 
                     ):
        """Search the FTDI I2C/SPI communication channels. 
        Args:
            i2c_devicename (List[bytes], optional): The list of FTDI channels that can be used as I2C device. If left empty, no I2C channel is opened. 
            i2c_ftdi_channel (int, optional): preselect FTDI channel for I2C operation, skip device search
        Returns:
            Status: The status code (OK = 0, error != 0)..
        """
        searching_for_i2c = True if i2c_devicename else False
        if i2c_ftdi_channel > -1:
            self.i2c_channel = i2c_ftdi_channel
            searching_for_i2c = False
        # if a FTDI channel is preselected for I2C operation use it and skip device search
        for i in range(self.getNumChannels()):
            info = self.getChannelInfo(i)
            if searching_for_i2c and (info.Description in i2c_devicename):
                searching_for_i2c = False # found an I2C device
                self.i2c_channel = i
        if searching_for_i2c:
            return self.FT_DEVICE_NOT_FOUND    
        return self.FT_OK

    def i2cOpen(self, i2c_speed:int=1000000 ):
        """Open the FTDI I2C communication channels, and configure their clock speeds. 
        Args:
            i2c_speed (int): the I2C frequency
        Returns:
            Status: The status code (OK = 0, error != 0)..
        """
        # if a FTDI channel is preselected for I2C operation use it and skip device search
        if self.i2c_channel > -1:
            super().i2cOpen(device_id=self.i2c_channel,clock_rate=i2c_speed)
            return self.FT_OK
        return self.FT_DEVICE_NOT_FOUND

if __name__ == "__main__":
    ''' Example: Open the communication, enable the device, read registers'''
    com = EvmFtdi(log=True,exception_on_error=False)
    com.search()
    print("Open ftdi communication channels")
    com.i2cOpen(i2c_speed=400000)

    data = com.i2cTxRx(0x41, [0x0], 0x10)
    print("Reading 16 registers: {}".format(list(map(hex, data))))
    com.i2cTx(0x41, [0xAB, 0xCD ])
    data = com.i2cRx(0x41, 2 )
    print("Reading 2 registers: {}".format(list(map(hex, data))))
    
    com.i2cClose()
        
    