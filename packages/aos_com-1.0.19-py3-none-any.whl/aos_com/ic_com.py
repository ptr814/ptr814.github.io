# *****************************************************************************
# * Copyright by ams OSRAM AG                                                 *
# * All rights are reserved.                                                  *
# *                                                                           *
# * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
# * THE SOFTWARE.                                                             *
# *                                                                           *
# * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
# * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
# * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
# * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
# * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
# * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
# * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES LOSS OF USE,      *
# * DATA, OR PROFITS OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
# * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
# * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
# * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
# *****************************************************************************
"""
This is a base class for communication with ICs. 
It supports I2C, SPI and GPIOs.
One typical example we have is the FTDI_MPSSE class.
"""

class IcCom:

    # Version log 
    # 1.0 first working version
    VERSION = 1.0
    
    # generic ok
    _OK = 0  
    _ERROR_PARAMETER_OUT_OF_RANGE = 254
    _ERROR_NOT_IMPLEMENTED = 255
    
    def _errToName(self, code:int ) -> str:
        """
        Convert error code to string.
        Args:
            code (int): The code that should become a string.
        Returns:
            str: Error code in text form.
        """
        if code == self._OK:                                return "_OK"
        elif code == self._ERROR_PARAMETER_OUT_OF_RANGE:    return "_ERROR_PARAMETER_OUT_OF_RANGE"
        elif code == self._ERROR_NOT_IMPLEMENTED:           return "_ERROR_NOT_IMPLEMENTED"
        else:                                               return "_ERROR_UNKNOWN_CODE"
        
    def _log(self, *message):
        """Log a message if logging is enabled. Overwrite this function to log to a file."""
        if self.logging_enabled:
            print(*message)
            
    def __init__(self, log=False, exception_on_error=True ):
        """
        Constructor, default is to not produce exceptions, just log the errors
        Args:
            log (TYPE, optional): Print messages. Defaults to False.
            exception_on_error (TYPE, optional): Raise an exception in error case, if false only log error. Defaults to False.
            enable_pin (int, optional): bit-mask defining the enable pin for gpioGet, gpioSet. Defaults to 0x01.
            interrupt_pin (int, optional): bit-mask defining the interrupt pin for gpioGet, gpioSet. Defaults to 0x02.
        """
        fn_name = "__init__"
        self.logging_enabled=log
        self.exception_on_error = exception_on_error # Raise exceptions 
        self.errors = []
        self.enable_pin = None                          # can be set by derived class
        self.interrupt_pin = None                       # can be set be derived class
        self._log("{} done".format(fn_name))

    def __del__(self):
        """Cleanup."""
        fn_name = "__del__"
        self._log("{} done".format(fn_name))

    def _setError(self, err_message:str, fn_name:str="unknown"):
        """Register an error in the error list. """
        message = "Error {} in function '{}'".format( err_message, fn_name )
        self.errors.append(message)
        if self.exception_on_error:
            raise RuntimeError(message)

    # -----------------------------------------------------------------------------------        
    # general public interface ----------------------------------------------------------
    # -----------------------------------------------------------------------------------
    
    def getFirstError(self) -> str:
        """Get the first error entry (if there is one, else return an empty string)
        Returns:
            txt(string): A printable string containing the function name and the error code.
        """
        if len(self.errors)>0:
            txt = self.errors.pop(0)
        else:
            txt = ''
        return txt

          
    # -----------------------------------------------------------------------------------        
    # SPI public interface --------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    # result is okay 
    SPI_OK = _OK

    # -----------------------------------------------------------------------------------        
    # SPI functions ---------------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    def spiOpen(self, spi_speed:int=10000000, spi_mode:int=3 ) -> int:
        """Open an SPI interface.
        Args:
            spi_speed(int): the Hertz for the SPI bus. Defaults to 10 MHz
            spi_mode(int): 0,1,2,3 == clock phase and clock polarity. Defaults to 3.
        Returns:
            int: status: 0 == ok, else error
        """
        fn_name = "spiOpen"
        status = self._ERROR_NOT_IMPLEMENTED
        self._log(fn_name)
        self._setError(self._errToName(status),fn_name)           
        return status 

    def spiClose(self) -> int:
        """ Function to close a SPI interface.
        Returns:
            int: status: 0 == ok, else error
        """
        fn_name = "spiClose"
        status = self._ERROR_NOT_IMPLEMENTED
        self._log(fn_name)
        self._setError(self._errToName(status),fn_name)           
        return status 

    def spiRx(self,rx_size:int) -> bytearray:
        """Function to receive the given number of bytes
        Args:
            rx_size(int): The number of bytes to receive.
            lsb_first(bool, optional): Bit order shall be little endian or big endian. The default is False = big endian.
        Returns:
            bytearray: Array of received bytes.
        """
        fn_name = "spiRx"
        status = self._ERROR_NOT_IMPLEMENTED
        self._log(fn_name)
        self._setError(self._errToName(status),fn_name)           
        return bytearray( 0 )

    def spiTx(self,tx:bytearray) -> int:
        """Function to transmit several bytes via SPI.
        Args:
            tx(list): byte list to transmit.
            lsb_first(bool, optional): If the FTDI should transmit in big-endian or little endian mode. The default is False (=big endian mode).
        Returns:
            int: status: 0 == ok, else error
        """
        fn_name = "spiTx"
        status = self._ERROR_NOT_IMPLEMENTED
        self._log(fn_name)
        self._setError(self._errToName(status),fn_name)           
        return status

    def spiTxRx(self,tx:bytearray,rx_size:int) -> bytearray:
        """Function to transmit and receive bytes. the function will extend the transmit list with 0 to match the receive length 
        if there are more bytes to receive than to transmit. the function will extend the receive bytearray
        with additionally read in bytes if the transmit length is greater than the receive length.
        Args:
            tx(list): list of bytes to transmit.
            rx_size(int): number of bytes to receive.
            lsb_first(bool, optional): If the FTDI should transmit in big-endian or little endian mode. The default is False (=big endian mode).
        Returns:
            bytearray: bytes received from the device.
        """
        fn_name = "spiTxRx"
        status = self._ERROR_NOT_IMPLEMENTED
        self._log(fn_name)
        self._setError(self._errToName(status),fn_name)           
        return bytearray( 0 )

    # -----------------------------------------------------------------------------------        
    # I2C public interface --------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    # result is okay 
    I2C_OK = _OK

    # -----------------------------------------------------------------------------------        
    # I2C functions ---------------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    def i2cOpen(self, i2c_speed:int=1000000) -> int:
        """Open an I2C interface.
        Args:
            i2c_speed(int)): i2c speed in Hz. 
        Returns:
            int: status: 0 == ok, else error
        """
        fn_name = "i2cOpen"
        status = self._ERROR_NOT_IMPLEMENTED
        self._log(fn_name)
        self._setError(self._errToName(status),fn_name)           
        return status 

    def i2cClose(self) -> int:
        """ Function to close a I2C interface. 
        Returns:
            int: status: 0 == ok, else error
        """
        fn_name = "i2cClose"
        status = self._ERROR_NOT_IMPLEMENTED
        self._log(fn_name)
        self._setError(self._errToName(status),fn_name)           
        return status 
    
    def i2cTx(self,devaddr:int,tx:list) -> int:
        """Function to transmit given bytes on I2C.
        Args:
            devaddr(int): the 7-bit I2C slave address (un-shifted).
            tx(list): a list of bytes to be transmitted.
        Returns:
            int: status: 0 == ok, else error
        """
        fn_name = "i2cTx"
        status = self._ERROR_NOT_IMPLEMENTED
        self._log(fn_name)
        self._setError(self._errToName(status),fn_name)           
        return status 

    def i2cRx(self,devaddr:int,rx_size:int) -> bytearray:
        """Function to receive bytes via I2C.
        Args:
            devaddr(int): the 7-bit I2C slave address (un-shifted).
            rx_size(int): the number of  bytes to be received.
        Returns:
            bytearray: array of bytes received.
        """
        fn_name = "i2cRx"
        status = self._ERROR_NOT_IMPLEMENTED
        self._log(fn_name)
        self._setError(self._errToName(status),fn_name)           
        return bytearray( 0 )

    def i2cTxRx(self,devaddr:int,tx:list,rx_size:int) -> bytearray:
        """Function to transmit and receive bytes via I2C.
        Args:
            devaddr(int): the 7-bit I2C slave address (un-shifted).
            tx(list): the list of bytes to be transmitted.
            rx_size(int): the number of  bytes to be received.
        Returns:
            bytearray: array of bytes received.
        """
        fn_name = "i2cTxRx"
        status = self._ERROR_NOT_IMPLEMENTED
        self._log(fn_name)
        self._setError(self._errToName(status),fn_name)           
        return bytearray( 0 )

    # -----------------------------------------------------------------------------------        
    # GPIO public interface -------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    def gpioGet(self,r_mask:int) -> int:
        """Get the value of one or more GPIO pins. Uses the I2C interface as handle.
        Args:
            r_mask(int): bit-mask. for every bit that is set the function will read in the value of the corresponding pin.
        Returns: 
            int: A single unsigned int representing the up to (16/8) GPIOs.
        """
        fn_name = "gpioGet"
        status = self._ERROR_NOT_IMPLEMENTED
        self._log(fn_name)
        self._setError(self._errToName(status),fn_name)           
        return 0
	
    def gpioSet(self,w_mask:int,value:int):
        """Set the value of one or more GPIO pins. Uses the I2C interface as handle.
        Args:
            w_mask(int): for every bit that is set the function will write the value as given with parameter <val>
            value(int): a bit-mask representing the bit values that shall be written.
        """
        fn_name = "gpioSet"
        status = self._ERROR_NOT_IMPLEMENTED
        self._log(fn_name)
        self._setError(self._errToName(status),fn_name)           

    def gpioSetDirection(self,out_mask:int,out_value:int):
        """Set the value of one or more GPIO pins and set them to out-put. 
        Args:
            out_mask(int): for every bit that is set the function will first set the bit to the value specified in out_value and then set the pin to output
            value(int): a bit-mask representing the bit values that shall be written.
        """
        fn_name = "gpioSetDirection"
        status = self._ERROR_NOT_IMPLEMENTED
        self._log(fn_name)
        self._setError(self._errToName(status),fn_name)           

    def gpioGetDirection(self):
        """Return the GPIO direction mask for all GPIO pins. When a bit is set, the pin is configured as output.
        """
        fn_name = "gpioGetDirection"
        status = self._ERROR_NOT_IMPLEMENTED
        self._log(fn_name)
        self._setError(self._errToName(status),fn_name)           

# to have a warning printed if you accidentially run this lib
if __name__ == "__main__":
    print ("WARNING: This is the IcCom class. Only for import in other programs.")
