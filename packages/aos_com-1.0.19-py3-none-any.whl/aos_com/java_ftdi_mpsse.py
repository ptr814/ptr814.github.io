# *****************************************************************************
# * Copyright by ams OSRAM AG                                                 *
# * All rights are reserved.                                                  *
# *                                                                           *
# * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
# * THE SOFTWARE.                                                             *
# *                                                                           *
# * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
# * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
# * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
# * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
# * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
# * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
# * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES LOSS OF USE,      *
# * DATA, OR PROFITS OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
# * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
# * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
# * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
# *****************************************************************************
"""
This is a wrapper for the libMPSSE for I2C , SPI and GPIO
"""

import __init__
from ctypes import *
import os
from sys import platform
from aos_com.ic_com import IcCom
import time
from java import jclass


# general information for any FTDI device
class FtdiDeviceListInfoNode(Structure):
    _fields_ =[("Flags", c_ulong),
               ("Type", c_ulong),
               ("ID", c_ulong),
               ("LocId", c_ulong),
               ("SerialNumber", c_char *16),
               ("Description", c_char * 64),
               ("ftHandle", c_void_p) ]

class FtdiChannelConfig(Structure):
    _fields_ = [("ClockRate", c_uint32),    # this is an enum
                ("LatencyTimer", c_uint32),             # this is an uint8 - but for padding I made it a 32-bit
                ("configOptions", c_uint32),
                ("Pin", c_uint32),
                ("currentPinState", c_uint16)]         # internal variable used by the FTDI lib to store previous state of pins


class FtdiMpsse(IcCom):

    # Version log 
    # 1.0 first working version
    # 1.1 support for multiple channels per device added 
    # 1.2 add an error list: errors
    # 1.3 support for bit-wise SPI added, support for little endian added
    # 1.4 Changed error handling to exceptions instead of return values (can be disabled).
    #     Removed status code from error list, only have error message.
    # 1.5 derive from base class ICCom
    VERSION = 1.5

    """The error codes that can come from the FTDI library. """
    
    FT_OK                           = IcCom._OK
    """The status is okay, no error recorded."""
    
    # error codes
    FT_INVALID_HANDLE               = 1
    FT_DEVICE_NOT_FOUND             = 2
    FT_DEVICE_NOT_OPENED            = 3
    FT_IO_ERROR                     = 4
    FT_INSUFFICIENT_RESOURCES       = 5
    FT_INVALID_PARAMETER            = 6
    FT_INVALID_BAUD_RATE            = 7

    FT_DEVICE_NOT_OPENED_FOR_ERASE  = 8
    FT_DEVICE_NOT_OPENED_FOR_WRITE  = 9
    FT_FAILED_TO_WRITE_DEVICE       = 10
    FT_EEPROM_READ_FAILED           = 11
    FT_EEPROM_WRITE_FAILED          = 12
    FT_EEPROM_ERASE_FAILED          = 13
    FT_EEPROM_NOT_PRESENT           = 14
    FT_EEPROM_NOT_PROGRAMMED        = 15
    FT_INVALID_ARGS                 = 16
    FT_NOT_SUPPORTED                = 17
    FT_OTHER_ERROR                  = 18
    FT_DEVICE_LIST_NOT_READY        = 19
    
    FT_NOT_WINDOWS                  = 20
    FT_NOT_LINUX                    = 21
    FT_LAST_ERROR_UNKNWON           = 22
    ''' if out of range value, use this artificial error '''

    errNames = [
        "FT_OK", "FT_INVALID_HANDLE", "FT_DEVICE_NOT_FOUND", "FT_DEVICE_NOT_OPENED", "FT_IO_ERROR", 
        "FT_INSUFFICIENT_RESOURCES", "FT_INVALID_PARAMETER", "FT_INVALID_BAUD_RATE", "FT_DEVICE_NOT_OPENED_FOR_ERASE", "FT_DEVICE_NOT_OPENED_FOR_WRITE", 
        "FT_FAILED_TO_WRITE_DEVICE", "FT_EEPROM_READ_FAILED", "FT_EEPROM_WRITE_FAILED", "FT_EEPROM_ERASE_FAILED", "FT_EEPROM_NOT_PRESENT", 
        "FT_EEPROM_NOT_PROGRAMMED", "FT_INVALID_ARGS", "FT_NOT_SUPPORTED", "FT_OTHER_ERROR", "FT_DEVICE_LIST_NOT_READY", 
        "FT_NOT_WINDOWS", "FT_LAST_ERROR_UNKNWON" ]

    def _errToName(self,code:int) -> str:
        """
        Convert error code to string.
        Args:
            code (int): the error code.
        Returns:
            str: text describing the error code.

        """
        if code < len( self.errNames) : return self.errNames[code]
        else:                           return super()._errToName(code)


    def __init__(self,log=False, exception_on_error=True, i2c_log_only:bool=False, libmpsse=None):
        """
        constructor
        Args:
            log (TYPE, optional): If True print to console. Defaults to False.
            exception_on_error (TYPE, optional): If True error are exceptions. Defaults to True.
        Raises:
            Exception: DESCRIPTION.
        """
        fn_name = "__init__"
        status = self.FT_OK
        super().__init__(log=log,exception_on_error=exception_on_error )
        self.i2c_log_only = i2c_log_only
        self.spi_handle = jclass("com.ftdi.j2xx.FT_Device")
        self.i2c_handle = jclass("com.ftdi.j2xx.FT_Device")
        self.errors = []
        if platform.startswith('linux'):
            if libmpsse is not None:
                self.ftdi_lib = libmpsse
                self._log("{}.JAVA libMPSSE successfully loaded".format(fn_name) )
        else:                                           # add here support for e.g. loading shared lib in linux
            status = self.FT_NOT_LINUX
            self.ftdi_lib = None
            self._setError(self._errToName(status),fn_name)

    def __del__(self):
        """Cleanup the library."""
        fn_name = "SPI_CloseChannel"
        if self.spi_handle:
            self._log("{} close spi_handle".format( fn_name ))
            self.ftdi_lib.SPI_CloseChannel(self.spi_handle)
            self.spi_handle = 0
        fn_name = "I2C_CloseChannel"
        if self.i2c_handle:
            self._log("{} close i2c_handle".format( fn_name ))
            self.ftdi_lib.I2C_CloseChannel(self.i2c_handle)
            self.i2c_handle = 0
        self._log(fn_name)
        self.ftdi_lib.Cleanup_libMPSSE()

    def _gpioGet(self,handle,r_mask:int,fn:str):
        """Get the value of one or more GPIO pins. For internal use only.
        Args:
            handle: the i2c_handle or spi_handle depening on which GPIOs are used
            r_mask(int): bit-mask which bits shall be read from GPIO
            fn(str): calling function name
        Returns:
            int: the read in bits from GPIO 
        """
        list = [0 , 0]
        v = bytearray(list)
        if handle == 0:
            self._setError( self._errToName(FtdiMpsse.FT_INVALID_HANDLE), fn + " FTDI library not available")
            return 0
        status = self.ftdi_lib.FT_ReadGPIO(handle, v)
        self._log(fn + '.FT_ReadGPIO: value=' + hex(v[0]) + ' rmask=' + hex(r_mask) + ' value&rmask=' + hex( v[0] & r_mask ))
        fnName = fn + '.FT_ReadGPIO'
        if status != self.FT_OK: self._setError(self._errToName(status), fnName)
        v[0] = v[0] & r_mask
        return v[0]

    def _gpioSet(self,handle,w_mask:int,value:int,fn:str):
        """Set the value of one or more GPIO pins. For internal use only.
        Args:
            handle: the i2c_handle or spi_handle depening on which GPIOs are used
            w_mask(int): bit-mask which bits shall be written to GPIO
            value(int): value that is bit-anded with w_mask and then written to GPIO
            fn(str): calling function name
        Returns:
            int: == FT_OK if write was ok, != FT_OK in error case
        """
        if handle == 0:
            self._setError( self._errToName(FtdiMpsse.FT_INVALID_HANDLE), fn + " FTDI library not available")
            return FtdiMpsse.FT_INVALID_HANDLE
        wm = self.toByte(w_mask)
        v = self.toByte(value)
        status = self.ftdi_lib.FT_WriteGPIO(handle, wm, v)
        fnName = fn + '.FT_WriteGPIO'
        self._log( fnName + ': dir=' + hex(wm), ' value=' + hex(v) + ' value&wmask=' + hex( v & wm ))
        if status != self.FT_OK: self._setError(self._errToName(status), fnName)
        return status

    def toByte(self, input):
        if input > 127:
            return (255 - input + 1) * -1
        else:
            return input
    # -----------------------------------------------------------------------------------        
    # general public interface ----------------------------------------------------------
    # -----------------------------------------------------------------------------------
    
    def printChannelInfo(self,dev_info:FtdiDeviceListInfoNode):
        """Print the FTDI channel information record
        Args:
            dev_info(FtdiDeviceListInfoNode): Print all the fields and values for an FTDI channel information.
        """
        for field_name, field_type in dev_info._fields_:
            self._log(field_name, getattr( dev_info, field_name))

    def getNumChannels(self):
        """Function returns the sum of the number of all FTDI device channels. I.e. if you have one FTDI device
            with 1 channel and one with 2 channels the function will return 3.
        Returns:
            int: The number of FTDI channels.
        """
        fn_name = "getNumChannels"
        num_channels = jclass("com.ams.libmpsse103.IntRef")()
        status = self.ftdi_lib.SPI_GetNumChannels(num_channels)
        if status != self.FT_OK:  self._setError(self._errToName(status), "{}.SPI_GetNumChannels".format(fn_name))
        self._log("{}.SPI_GetNumChannels: Status={} Found channels={}".format(fn_name,self._errToName(status), str(num_channels.val)))
        return num_channels.val

    def getChannelInfo(self,channel_num=0) -> FtdiDeviceListInfoNode:
        """Get for the specified channel the information record from the HW. Channel
            numbers start with 0.
        Args:
            channel_num(int, optional): For which channel the information shall be returned. The default is 0.
        Returns:
            FtdiDeviceListInfoNode: The device information record for the specified channel.
        """
        fn_name = "getChannelInfo"
        dev_info = FtdiDeviceListInfoNode()
        dev_info_java = jclass("com.ams.libmpsse103.DeviceInfoListNode")()
        status = self.ftdi_lib.SPI_GetChannelInfo(channel_num, dev_info_java)

        serialNumber = bytes(dev_info_java.serialNumber, 'utf-8')
        description = bytes(dev_info_java.description, 'utf-8')

        setattr(dev_info, "Flags", dev_info_java.flags)
        setattr(dev_info, "Type", dev_info_java.type)
        setattr(dev_info, "ID", dev_info_java.id)
        setattr(dev_info, "LocId", dev_info_java.location)
        setattr(dev_info, "SerialNumber", serialNumber)
        setattr(dev_info, "Description", description)
        setattr(dev_info, "ftHandle", dev_info_java.handle)

        if self.logging_enabled:
            self._log("{}.SPI_GetChannelInfo: channel={}".format(fn_name,channel_num))
            if status == self.FT_OK: 
                self.printChannelInfo(dev_info)
            else: 
                self._log("{}.SPI_GetChannelInfo: Error readout, status={}".format(fn_name,self._errToName(status)))
        if status != self.FT_OK: self._setError(self._errToName(status), "{}.SPI_GetChannelInfo".format(fn_name))
        return dev_info

    def serialNumberToChannel(self,serial_number: bytearray) -> int:
        """Search for a device with the given serial number, and return the channel number for this device
        Args:
            serial_number (bytearray): e.g. b'FT66FVUBB'
        Returns:
            >=0 : channel id, 
            <0 : error case
        """
        fn_name = "serialNumberToChannel"
        status = self.FT_DEVICE_NOT_FOUND
        channels = self.getNumChannels( )
        for i in range( channels ):
            dev_info = self.getChannelInfo(i) 
            if ( serial_number == getattr(dev_info, "SerialNumber")):
                self._log("{}: {} is channel {}".format(fn_name, str(serial_number), i ))
                return i
        if status != self.FT_OK: self._setError(self._errToName(status), fn_name)
        return -1

    def spiChangeCS(self,configOptions:int):
        """This function changes the chip select line that is to be used to communicate to the SPI slave.
        Args:
            configOptions(int): This parameter provides a way to select the chip select line and the slave's SPI mode. 
                It is the same parameter as ConfigChannel.configOptions that is passed to function SPI_InitChannel.        
        Returns:
            int: == FT_OK if was ok, != FT_OK in error case
        """
        fn_name = "spiChangesCS"
        if self.spi_handle == 0:
            self._setError( self._errToName(FtdiMpsse.FT_INVALID_HANDLE), fn_name + " FTDI library not available")
            return FtdiMpsse.FT_INVALID_HANDLE
        status=self.ftdi_lib.SPI_ChangeCS(self.spi_handle, configOptions)
        return status
           
    # -----------------------------------------------------------------------------------        
    # SPI public interface --------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    # result is okay 
    SPI_OK                                      = FT_OK
    # all the SPI stuff goes here
    #/* Bit defination of the transferOptions parameter in SPI_Read, SPI_Write & SPI_Transfer  */
    #/* transferOptions-Bit0: If this bit is 0 then it means that the transfer size provided is in bytes */
    SPI_TRANSFER_OPTIONS_SIZE_IN_BYTES          = 0x00000000
    #/* transferOptions-Bit0: If this bit is 1 then it means that the transfer size provided is in bytes */
    SPI_TRANSFER_OPTIONS_SIZE_IN_BITS           = 0x00000001
    #/* transferOptions-Bit1: if BIT1 is 1 then CHIP_SELECT line will be enabled at start of transfer */
    SPI_TRANSFER_OPTIONS_CHIPSELECT_ENABLE      = 0x00000002
    #/* transferOptions-Bit2: if BIT2 is 1 then CHIP_SELECT line will be disabled at end of transfer */
    SPI_TRANSFER_OPTIONS_CHIPSELECT_DISABLE     = 0x00000004
    #/* transferOptions-Bit3: if BIT3 is 1 then LSB will be processed first */
    SPI_TRANSFER_OPTIONS_LSB_FIRST              = 0x00000008
    #/* Bit defination of the Options member of configOptions structure*/
    SPI_CONFIG_OPTION_MODE_MASK                 = 0x00000003
    SPI_CONFIG_OPTION_MODE0	                    = 0x00000000
    SPI_CONFIG_OPTION_MODE1	                    = 0x00000001
    SPI_CONFIG_OPTION_MODE2	                    = 0x00000002
    SPI_CONFIG_OPTION_MODE3	                    = 0x00000003
    SPI_CONFIG_OPTION_CS_MASK                   = 0x0000001C		#/*111 00*/
    SPI_CONFIG_OPTION_CS_DBUS3	                = 0x00000000		#/*000 00*/
    SPI_CONFIG_OPTION_CS_DBUS4	                = 0x00000004		#/*001 00*/
    SPI_CONFIG_OPTION_CS_DBUS5	                = 0x00000008		#/*010 00*/
    SPI_CONFIG_OPTION_CS_DBUS6	                = 0x0000000C		#/*011 00*/
    SPI_CONFIG_OPTION_CS_DBUS7	                = 0x00000010		#/*100 00*/
    SPI_CONFIG_OPTION_CS_ACTIVELOW              = 0x00000020

    # -----------------------------------------------------------------------------------        
    # SPI functions ---------------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    def toInt(self, input):
        if input > 0x7FFFFFFF:
            return (0xFFFFFFFF - input + 1) * -1
        else:
            return input

    def spiOpen(self,device_id:int=0,clock_rate:int=10000000, latency_timer:int=1,options:int= SPI_CONFIG_OPTION_MODE3 | SPI_CONFIG_OPTION_CS_DBUS3
                                                                             | SPI_CONFIG_OPTION_CS_ACTIVELOW, pins:int=0xFF00FF00, lsb_first:bool=False) -> int:
        """Open an SPI interface.

        Args:
            device_id(int, optional):  which FTDI device/channel of device to use. The default is 0.
            clock_rate(int, optional): The SPI speed (default is 10MHz, must be an integer divider of 30MHz for FT2232H, FT232H). The default is 10000000.
            latency_timer(int, optional): This influences the communication performance on the PC, the higher the slower (range is 0..16). The default is 1.
            options(int, optional): Must be set to select SPI mode (0..3) and which pin should be CS. Default is SPI mode 3 + D3=CS. 
            pins(int, optional): pin default direction and states before and after SPI is opened and closed. The default is 0xFF00FF00. 
                bit7..0 = initial direction of pins (0=in,1=out), bit15..8 = initial value of pins, 
                bit23..16 = final direction of pins, bit31..24 = final value of bits
            lsb_first(bool,optional): if byte shall be transmitted lsb first or msb first. Default is False.
        Returns:
            int: == FT_OK if open was ok, != FT_OK in error case
        """
        fn_name = "spiOpen"
        self.lsb_first = lsb_first
        spi_handle_ref = jclass("com.ams.libmpsse103.FT_DeviceRef")()
        # always use channel 0, FT232H has only this one
        status = self.ftdi_lib.SPI_OpenChannel(device_id, spi_handle_ref)
        self.spi_handle = spi_handle_ref.val
        self._log("{}.SPI_OpenChannel: Status={} handle={}".format(fn_name,self._errToName(status),str(self.spi_handle)))
        if status != self.FT_OK: self._setError(self._errToName(status),"{}.SPI_OpenChannel".format(fn_name))
        if status == self.FT_OK:
            cfg = FtdiChannelConfig(ClockRate=clock_rate, LatencyTimer=latency_timer,configOptions=options,Pin=pins,currentPinState=0)
            if self.logging_enabled: 
                for field_name, field_type in cfg._fields_:
                    self._log(field_name, getattr(cfg, field_name))
            spi_config_java = jclass("com.ams.libmpsse103.SPIChannelConfig")()
            spi_config_java.ClockRate = clock_rate
            spi_config_java.LatencyTimer = latency_timer
            spi_config_java.configOptions = options
            spi_config_java.Pin = self.toInt(pins)
            spi_config_java.currentPinState = 0
            status = self.ftdi_lib.SPI_InitChannel(self.spi_handle, spi_config_java)
            self._log("{}.SPI_InitChannel: Status={}".format(fn_name,self._errToName(status)))
            if status != self.FT_OK: self._setError(self._errToName(status),"{}.SPI_InitChannel".format(fn_name))
        return status

    def spiClose(self) -> int:
        """ Function to close a SPI interface. """
        fn_name = "spiClose"
        status = self.FT_OK
        if ( self.spi_handle ):
            status = self.ftdi_lib.SPI_CloseChannel(self.spi_handle)
            self._log("{}.SPI_CloseChannel: Status={}".format(fn_name,self._errToName(status)))
            if status != self.FT_OK: self._setError(self._errToName(status),"{}.SPI_CloseChannel".format(fn_name))
            self.spi_handle = 0
        else:
            self._log(fn_name)
        return status

    def bits2array(self, tx:list, n_bits:int) -> list:
        """Generate an array where each bit represents one entry
        Args:
            tx(list): The list of bytes transmitted or received.
            n_bits(int): number of bits.
        Returns:
            list: List of bits.
        """
        ret=[]
        for i in range(n_bits):
            ret.append((tx[i//8]>>(i%8))&1)
        return ret

    def spiRxBits(self,n_bits:int) -> bytearray:
        """Function to receive a number of bits.
        Args:
            n_bits(int): number of bits to receive. Maximum is 8.

        Returns:
            byte: The received bits.
        """
        fn_name = "spiRxBits"
        if self.spi_handle == 0:
            self._setError( self._errToName(FtdiMpsse.FT_INVALID_HANDLE), fn_name + " FTDI library not available")
            return bytearray(0)
        status = self.FT_OK
        if ( n_bits > 8 ):
            status = self.FT_OTHER_ERROR
            self._setError(self._errToName(status), "{} too many bits ({}) to rx".format(fn_name, n_bits))
            return 0
        if ( self.lsb_first ):
            options = (self.SPI_TRANSFER_OPTIONS_CHIPSELECT_ENABLE | self.SPI_TRANSFER_OPTIONS_CHIPSELECT_DISABLE
                               | self.SPI_TRANSFER_OPTIONS_SIZE_IN_BITS | self.SPI_TRANSFER_OPTIONS_LSB_FIRST)
        else:
            options = (self.SPI_TRANSFER_OPTIONS_CHIPSELECT_ENABLE | self.SPI_TRANSFER_OPTIONS_CHIPSELECT_DISABLE
                               | self.SPI_TRANSFER_OPTIONS_SIZE_IN_BITS)
        rx_size = 1
        ba = bytearray( [0] )
        #rx_buffer = (c_ubyte * rx_size).from_buffer( ba )
        #size_txed = c_uint32(0)
        size_txed = jclass("com.ams.libmpsse103.IntRef")()
        status = self.ftdi_lib.SPI_Read( self.spi_handle, ba, n_bits, size_txed, options)
        #rx_ba = bytearray( rx_buffer )
        rx_ba = bytearray( ba )
        rx_ba[0] = rx_ba[0] >> (8-n_bits)
        self._log("{}.SPI_Read({}) status={} rxed={}".format(fn_name,n_bits, self._errToName(status),self.bits2array(rx_ba, n_bits)))
        if status != self.FT_OK: self._setError(self._errToName(status),"{}.SPI_Read".format(fn_name))
        return rx_ba[0]

    def spiTxBits(self,tx:int,n_bits:int) -> int:
        """Function to transmit a number of bits.
        Args:
            tx(int): single value to transmit.
            n_bits(int): number of bits to transmit. <= 8 bits.
        Returns:
            int: if ok == 0, else error
        """
        fn_name = "spiTxBits"
        if self.spi_handle == 0:
            self._setError( self._errToName(FtdiMpsse.FT_INVALID_HANDLE), fn_name + " FTDI library not available")
            return FtdiMpsse.FT_INVALID_HANDLE
        status = self.FT_OK
        if ( n_bits > 8 ):
            status = self.FT_OTHER_ERROR
            self._setError(self._errToName(status), "{} too many bits ({}) to tx".format(fn_name, n_bits))
            return status
        if ( self.lsb_first ):
            options = ( self.SPI_TRANSFER_OPTIONS_CHIPSELECT_ENABLE | self.SPI_TRANSFER_OPTIONS_CHIPSELECT_DISABLE
                               | self.SPI_TRANSFER_OPTIONS_SIZE_IN_BITS | self.SPI_TRANSFER_OPTIONS_LSB_FIRST )
        else:
            options = ( self.SPI_TRANSFER_OPTIONS_CHIPSELECT_ENABLE | self.SPI_TRANSFER_OPTIONS_CHIPSELECT_DISABLE
                               | self.SPI_TRANSFER_OPTIONS_SIZE_IN_BITS )
        tx_ba = bytearray( [tx] )
        ltx = 1
        #tx_buffer = (c_ubyte * ltx).from_buffer( tx_ba )
        size_txed = jclass("com.ams.libmpsse103.IntRef")()
        status = self.ftdi_lib.SPI_Write( self.spi_handle, tx_ba, n_bits, size_txed, options)
        self._log("{}.SPI_Write({}) status={} totx={}".format(fn_name,n_bits, self._errToName(status),self.bits2array(tx_ba, n_bits)))
        if status != self.FT_OK: self._setError(self._errToName(status),"{}.SPI_Write".format(fn_name))
        return status
    
    def spiRx(self,rx_size:int) -> bytearray:
        """Function to receive the given number of bytes
        Args:
            rx_size(int): The number of bytes to receive.
        Returns:
            bytearray: Array of received bytes.
        """
        fn_name = "spiRx"
        if self.spi_handle == 0:
            self._setError( self._errToName(FtdiMpsse.FT_INVALID_HANDLE), fn_name + " FTDI library not available")
            return bytearray(0)
        status = self.FT_OK
        if ( self.lsb_first):
            options = ( self.SPI_TRANSFER_OPTIONS_CHIPSELECT_ENABLE | self.SPI_TRANSFER_OPTIONS_CHIPSELECT_DISABLE
                              | self.SPI_TRANSFER_OPTIONS_LSB_FIRST )
        else:
            options = (self.SPI_TRANSFER_OPTIONS_CHIPSELECT_ENABLE | self.SPI_TRANSFER_OPTIONS_CHIPSELECT_DISABLE )
        #size = c_uint32(rx_size)
        ba = bytearray( rx_size )
        #rx_buffer = (c_ubyte * rx_size).from_buffer( ba )
        size_rxed = jclass("com.ams.libmpsse103.IntRef")()
        status = self.ftdi_lib.SPI_Read( self.spi_handle, ba, rx_size, size_rxed, options)
        self._log("{}.SPI_Read status={} rxed={}".format(fn_name, self._errToName(status),rx_size))
        if status != self.FT_OK: self._setError(self._errToName(status),"{}.SPI_Read".format(fn_name))
        if ( status == self.FT_OK ): 
            #rx_ba = bytearray( rx_buffer )
            rx_ba = bytearray( ba )
        else:        
            rx_ba = bytearray( 0 )
        self._log("{}.SPI_Read: Buffer=0x{}".format(fn_name,rx_ba.hex()))
        return rx_ba

    def spiTx(self,tx:list) -> int:
        """Function to transmit several bytes via SPI.
        Args:
            tx(list): byte list to transmit.
        Returns:
            int: if ok == 0, else error
        """
        fn_name = "spiTx"
        if self.spi_handle == 0:
            self._setError( self._errToName(FtdiMpsse.FT_INVALID_HANDLE), fn_name + " FTDI library not available")
            return FtdiMpsse.FT_INVALID_HANDLE
        status = self.FT_OK
        if ( self.lsb_first):
            options = c_uint32( self.SPI_TRANSFER_OPTIONS_CHIPSELECT_ENABLE | self.SPI_TRANSFER_OPTIONS_CHIPSELECT_DISABLE 
                              | self.SPI_TRANSFER_OPTIONS_LSB_FIRST )
        else:
            options = c_uint32( self.SPI_TRANSFER_OPTIONS_CHIPSELECT_ENABLE | self.SPI_TRANSFER_OPTIONS_CHIPSELECT_DISABLE )
        tx_ba = bytearray( tx )
        ltx = len(tx_ba)
        #size = c_uint32( ltx )
        #tx_buffer = (c_ubyte * ltx).from_buffer( tx_ba )
        size_txed = jclass("com.ams.libmpsse103.IntRef")()
        status = self.ftdi_lib.SPI_Write( self.spi_handle, tx_ba, ltx, size_txed, options)
        self._log("{}.SPI_Write status={} toTx={}".format(fn_name, self._errToName(status),ltx))
        if status != self.FT_OK: self._setError(self._errToName(status),"{}.SPI_Write".format(fn_name))
        self._log("{}.SPI_Write Buffer=0x{}".format(fn_name,tx_ba.hex()))
        return status

    def spiTxRx(self,tx:list,rx_size:int) -> bytearray:
        """Function to transmit and receive bytes. the function will extend the transmit list with 0 to match the receive length 
            if there are more bytes to receive than to transmit. the function will extend the receive bytearray
            with additionally read in bytes if the transmit length is greater than the receive length.
        Args:
            tx(list): list of bytes to transmit.
            rx_size(int): number of bytes to receive.
        Returns:
            bytearray: bytes received from the device.
        """
        fn_name = "spiTxRx"
        if self.spi_handle == 0:
            self._setError( self._errToName(FtdiMpsse.FT_INVALID_HANDLE), fn_name + " FTDI library not available")
            return bytearray(0)
        status = self.FT_OK
        if ( self.lsb_first):
            options = ( self.SPI_TRANSFER_OPTIONS_CHIPSELECT_ENABLE | self.SPI_TRANSFER_OPTIONS_CHIPSELECT_DISABLE
                              | self.SPI_TRANSFER_OPTIONS_LSB_FIRST )
        else:
            options = ( self.SPI_TRANSFER_OPTIONS_CHIPSELECT_ENABLE | self.SPI_TRANSFER_OPTIONS_CHIPSELECT_DISABLE )
        tx_ba = bytearray( tx )
        ltx = len(tx_ba)
        if ( ltx < rx_size ): 
            tmp = [0]*(rx_size-ltx)
            tx_ba.extend( tmp )   #extend with 0s
            ltx = rx_size
        #tx_buffer = (c_ubyte * ltx).from_buffer( tx_ba )
        rx_ba = bytearray( [0]*rx_size)
        #rx_buffer = (c_ubyte * rx_size).from_buffer( rx_ba )
        #tx_size = c_uint32(ltx)
        size_txed = jclass("com.ams.libmpsse103.IntRef")()
        status = self.ftdi_lib.SPI_ReadWrite( self.spi_handle, rx_ba, tx_ba, ltx, size_txed, options)
        if ( status == self.SPI_OK ): 
            rx_ba_ret = bytearray( rx_ba )
        else:        
            rx_ba_ret = bytearray( 0 )
        self._log("{}.SPI_ReadWrite status={} toTx/rxed={}".format(fn_name, self._errToName(status),ltx))
        if status != self.FT_OK: self._setError(self._errToName(status),"{}.SPI_ReadWrite".format(fn_name))
        self._log("{}.SPI_ReadWrite TxBuffer=0x{}  RxBuffer=0x{}".format(fn_name, tx_ba.hex(), rx_ba.hex()))
        return rx_ba_ret

    # -----------------------------------------------------------------------------------        
    # I2C public interface --------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    # result is okay 
    I2C_OK = FT_OK
    # all the I2C stuff goes here
    # Options to I2C_DeviceWrite & I2C_DeviceRead */
    # Generate start condition before transmitting */
    I2C_TRANSFER_OPTIONS_START_BIT		= 0x00000001
    #Generate stop condition before transmitting */
    I2C_TRANSFER_OPTIONS_STOP_BIT		= 0x00000002
    #Continue transmitting data in bulk without caring about Ack or nAck from device if this bit is
    # not set. If this bit is set then stop transitting the data in the buffer when the device nAcks*/
    I2C_TRANSFER_OPTIONS_BREAK_ON_NACK = 0x00000004
    # libMPSSE-I2C generates an ACKs for every byte read. Some I2C slaves require the I2C
    # master to generate a nACK for the last data byte read. Setting this bit enables working with such
    # I2C slaves */
    I2C_TRANSFER_OPTIONS_NACK_LAST_BYTE = 0x00000008
    # no address phase, no USB interframe delays */
    I2C_TRANSFER_OPTIONS_FAST_TRANSFER_BYTES	= 0x00000010
    I2C_TRANSFER_OPTIONS_FAST_TRANSFER_BITS	= 0x00000020
    I2C_TRANSFER_OPTIONS_FAST_TRANSFER		   = 0x00000030
    # if I2C_TRANSFER_OPTION_FAST_TRANSFER is set then setting this bit would mean that the
    # address field should be ignored. The address is either a part of the data or this is a special I2C
    # frame that doesn't require an address*/
    I2C_TRANSFER_OPTIONS_NO_ADDRESS          = 0x00000040
    I2C_CMD_GETDEVICEID_RD	= 0xF9
    I2C_CMD_GETDEVICEID_WR	= 0xF8
    I2C_GIVE_ACK	 = 1
    I2C_GIVE_NACK	 = 0
    # 3-phase clocking is enabled by default. Setting this bit in ConfigOptions will disable it */
    I2C_DISABLE_3PHASE_CLOCKING   = 0x0001
    # The I2C master should actually drive the SDA line only when the output is LOW. It should be
    # tristate the SDA line when the output should be high. This tristating the SDA line during output
    # HIGH is supported only in FT232H chip. This feature is called DriveOnlyZero feature and is
    # enabled when the following bit is set in the options parameter in function I2C_Init */
    I2C_ENABLE_DRIVE_ONLY_ZERO	 = 0x0002

    # -----------------------------------------------------------------------------------        
    # I2C functions ---------------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    def i2cOpen(self,device_id:int=0,clock_rate:int=1000000,latency_timer:int=1,options:int=I2C_ENABLE_DRIVE_ONLY_ZERO,pins:int=0xFF00FF00) -> int:
        """Function to open the FTDI device in I2C master mode.
        Args:
            device_id(int, optional): number of the FTDI channel to use for I2C. The default is 0.
            clock_rate(int, optional): clock rate in Hertz. The default is 1000000. maximum speed is 3.4MHz
            latency_timer(int, optional): latency timer, range is 0..16. The default is 1.
            options(int, optional): i2c specific options for the FTDI library. The default is I2C_ENABLE_DRIVE_ONLY_ZERO.
            pins(int, optional): pin state before and after the FTDI library is opened/closed. The default is 0xFF00FF00.
        Returns:
            int: if ok == 0, else error
        """
        fn_name = "i2cOpen"
        status = self.FT_OK
        #self.i2c_handle=c_void_p()
        i2c_handle_ref = jclass("com.ams.libmpsse103.FT_DeviceRef")()
        #channel = c_uint32(device_id)           # always use channel 0, FT232H has only this one
        status = self.ftdi_lib.I2C_OpenChannel(device_id, i2c_handle_ref)
        self.i2c_handle = i2c_handle_ref.val
        self._log("{}.I2C_OpenChannel: Status={} handle={}".format(fn_name, self._errToName(status), str(self.i2c_handle)))
        if status != self.FT_OK: 
            self._setError(self._errToName(status),"{}.I2C_OpenChannel".format(fn_name))
            self.i2c_handle = 0
        else:
            cfg = FtdiChannelConfig(ClockRate=clock_rate, LatencyTimer=latency_timer,Options=options,Pin=pins,currentPinState=0)
            if self.logging_enabled:  
                for field_name, field_type in cfg._fields_:
                    self._log(field_name, getattr(cfg, field_name))

            i2c_config_java = jclass("com.ams.libmpsse103.I2CChannelConfig")()
            i2c_config_java.ClockRate = clock_rate
            i2c_config_java.LatencyTimer = latency_timer
            i2c_config_java.Options = options
            #i2c_config_java.Pin = pins
            #i2c_config_java.currentPinState = 0
            status = self.ftdi_lib.I2C_InitChannel(self.i2c_handle, i2c_config_java)
            self._log("{}.I2C_InitChannel: Status={}".format(fn_name,self._errToName(status)))
            if status != self.FT_OK: self._setError(self._errToName(status),"{}.I2C_InitChannel".format(fn_name))
        return status

    def i2cClose(self) -> int:
        """Function to close the I2C interface.
        Returns:
            int: if ok == 0, else error
        """
        fn_name = "i2cClose"
        status = self.FT_OK
        if self.i2c_handle:
            status = self.ftdi_lib.I2C_CloseChannel(self.i2c_handle)
            self._log("{}.I2C_CloseChannel: Status={}".format(fn_name,self._errToName(status)))
            if status != self.FT_OK: self._setError(self._errToName(status),"{}.I2C_CloseChannel".format(fn_name))
            self.i2c_handle = 0
        else:
            self._log(fn_name)
        return status

    def i2cTx(self,devaddr:int,tx:list) -> int:
        """Function to transmit given bytes on I2C.
        Args:
            devaddr(int): the 7-bit I2C slave address (un-shifted).
            tx(list): a list of bytes to be transmitted.
        Returns:
            int: if ok == 0, else error
        """
        fn_name = "i2cTx"
        if self.i2c_handle == 0:
            self._setError( self._errToName(FtdiMpsse.FT_INVALID_HANDLE), fn_name + " FTDI library not available")
            return FtdiMpsse.FT_INVALID_HANDLE
        status = self.FT_OK
        tx_ba = bytearray( tx )
        len_tx = len(tx_ba)
        #tx_buffer = (c_ubyte * l).from_buffer( tx_ba )
        dev_addr = self.toByte(devaddr)
        #tx_size = c_uint32(l)
        size_txed = jclass("com.ams.libmpsse103.IntRef")()
        options = (self.I2C_TRANSFER_OPTIONS_FAST_TRANSFER_BYTES | self.I2C_TRANSFER_OPTIONS_START_BIT | self.I2C_TRANSFER_OPTIONS_STOP_BIT
                 | self.I2C_TRANSFER_OPTIONS_NACK_LAST_BYTE)
        status = self.ftdi_lib.I2C_DeviceWrite( self.i2c_handle, dev_addr, len_tx, tx_ba, size_txed, options)
        self._log("{}.I2C_DeviceWrite: Status={} txed={}".format(fn_name,self._errToName(status), str(size_txed.val)))
        if status != self.FT_OK: self._setError(self._errToName(status),"{}.I2C_DeviceWrite".format(fn_name))
        self._log("{}.I2C_DeviceWrite: Buffer=0x".format(fn_name) + tx_ba.hex())
        if self.i2c_log_only:
            print("{:1.3f} I2C-TX: dev-addr={}: {}".format(time.time()%10, hex(devaddr),' '.join( hex(x) for x in list(tx_ba) ) ) ) 
        return status

    def i2cRx(self,devaddr:int,rx_size:int) -> bytearray:
        """Function to receive bytes via I2C.
        Args:
            devaddr(int): the 7-bit I2C slave address (un-shifted).
            rx_size(int): the number of  bytes to be received.
        Returns:
            bytearray: array of bytes received.
        """
        fn_name = "i2cRx"
        if self.i2c_handle == 0:
            self._setError( self._errToName(FtdiMpsse.FT_INVALID_HANDLE), fn_name + " FTDI library not available")
            return bytearray(0)
        status = self.FT_OK
        rx_buffer = bytearray(rx_size)
        #len_rx = rx_size
        #rx_buffer = (c_ubyte * len_rx)()
        dev_addr = self.toByte(devaddr)
        #rx_size = c_uint32(len_rx)
        size_rxed = jclass("com.ams.libmpsse103.IntRef")()
        options = (self.I2C_TRANSFER_OPTIONS_FAST_TRANSFER_BYTES | self.I2C_TRANSFER_OPTIONS_START_BIT | self.I2C_TRANSFER_OPTIONS_STOP_BIT
                 | self.I2C_TRANSFER_OPTIONS_NACK_LAST_BYTE)
        status = self.ftdi_lib.I2C_DeviceRead( self.i2c_handle, dev_addr, rx_size, rx_buffer, size_rxed, options)
        if status == self.FT_OK: 
            rx_ba = bytearray( rx_buffer )
        else: 
            rx_ba = bytearray( 0 )
        self._log("{}.I2C_DeviceRead: Status={} rxed={}".format(fn_name,self._errToName(status), str(size_rxed.val)))
        if status != self.FT_OK: self._setError(self._errToName(status),"{}.I2C_DeviceRead".format(fn_name))
        self._log("{}.I2C_DeviceRead: Buffer=0x".format(fn_name) + rx_ba.hex())
        if self.i2c_log_only:
            print("{:1.3f} I2C-RX: dev-addr={}: {}".format(time.time()%10, hex(devaddr),' '.join( hex(x) for x in list(rx_ba) ) ) ) 
        return rx_ba

    def i2cTxRx(self, devaddr:int, tx:list, rx_size:int) -> bytearray:
        """Function to transmit and receive bytes via I2C.
        Args:
            devaddr(int): the 7-bit I2C slave address (un-shifted).
            tx(list): the list of bytes to be transmitted.
            rx_size(int): the number of  bytes to be received.
        Returns:
            bytearray: array of bytes received.
        """
        fn_name = "i2cTxRx"
        if self.i2c_handle == 0:
            self._setError( self._errToName(FtdiMpsse.FT_INVALID_HANDLE), fn_name + " FTDI library not available")
            return bytearray(0)
        status = self.FT_OK
        dev_addr = self.toByte(devaddr)
        if (rx_size == 0):
            self.i2cTx(dev_addr,tx)
            return bytearray(0)
        optionsNoStop = ( self.I2C_TRANSFER_OPTIONS_FAST_TRANSFER_BYTES | self.I2C_TRANSFER_OPTIONS_START_BIT )
        optionsStop   = ( self.I2C_TRANSFER_OPTIONS_FAST_TRANSFER_BYTES | self.I2C_TRANSFER_OPTIONS_START_BIT
                        | self.I2C_TRANSFER_OPTIONS_STOP_BIT | self.I2C_TRANSFER_OPTIONS_NACK_LAST_BYTE)
        rx_ba = bytearray( 0 )
        # first transmit data
        tx_ba = bytearray( tx )
        ltx = len(tx_ba)
        #tx_buffer = (c_ubyte * ltx).from_buffer( tx_ba )
        #tx_size = c_uint32(ltx)
        size_txed = jclass("com.ams.libmpsse103.IntRef")()
        status = self.ftdi_lib.I2C_DeviceWrite( self.i2c_handle, dev_addr, ltx, tx_ba, size_txed, optionsNoStop)
        self._log("{}.I2C_DeviceWrite: Status={} txed={}".format(fn_name,self._errToName(status),str(size_txed.val)))
        if status != self.FT_OK: self._setError(self._errToName(status),"{}.I2C_DeviceWrite".format(fn_name))
        self._log("{}.I2C_DeviceWrite: Buffer=0x".format(fn_name) + tx_ba.hex())
        if self.i2c_log_only:
            print("{:1.3f} I2C-Tx: dev-addr={}: {}".format(time.time()%10, hex(devaddr),' '.join( hex(x) for x in list(tx_ba) ) ) ) 
        if status == self.FT_OK:
            # 2nd receive if transmit was ok
            #lrx = rx_size
            #rx_buffer = (c_ubyte * lrx)()
            rx_buffer = bytearray( rx_size )
            #rx_size = c_uint32(lrx)
            size_rxed = jclass("com.ams.libmpsse103.IntRef")()
            status = self.ftdi_lib.I2C_DeviceRead( self.i2c_handle, dev_addr, rx_size, rx_buffer, size_rxed, optionsStop)
            if status == self.FT_OK: 
                rx_ba = bytearray( rx_buffer )
            else: 
                rx_ba = bytearray( 0 )
            self._log("{}.I2C_DeviceRead: Status={} rxed={}".format(fn_name,self._errToName(status), str(size_rxed.val)))
            if status != self.FT_OK: self._setError(self._errToName(status),"{}.I2C_DeviceRead".format(fn_name))
            self._log("{}.I2C_DeviceRead: Buffer=0x".format(fn_name) + rx_ba.hex())
            if self.i2c_log_only:
                print("{:1.3f} I2C-Rx: dev-addr={}: {}".format(time.time()%10, hex(devaddr),' '.join( hex(x) for x in list(rx_ba) ) ) ) 
        return rx_ba

    # -----------------------------------------------------------------------------------        
    # GPIO public interface -------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    def gpioGet(self,r_mask:int):
        """Get the value of one or more GPIO pins. Uses the I2C interface as handle.
            Lower 8 bit are the I2C handle (ACBUS)
            Higher 8 bit are the SPI handle (ADBUS)
        Args:
            rmask(byte): bit-mask. for every bit that is set the function will read in the value of the corresponding pin.
        Returns: 
            byte: A single byte representing the up to 8 GPIOs.
        """
        fn_name = "gpioGet"
        value = 0
        if ( r_mask & 0x00FF ):
            value = value + self._gpioGet(self.i2c_handle, r_mask & 0xFF, "{}(low  byte)".format(fn_name))
        if ( r_mask & 0xFF00 ):
            value = value + ( self._gpioGet(self.spi_handle, r_mask >> 8, "{}(high byte)".format(fn_name)) << 8 )
        return value
	
    def gpioSet(self, w_mask:int, value:int, fn_name:str="gpioSet"):
        """Set the value of one or more GPIO pins. Uses the I2C interface as handle.
            Lower 8 bit are the I2C handle (ACBUS)
            Higher 8 bit are the SPI handle (ADBUS)
        Args:
            w_mask(byte): for every bit that is set the function will write the value as given with parameter <val>
            value(byte): a bit-mask representing the bit values that shall be written.
            fn_name(str): name for logging, defaults to gpioSet
        """
        if ( w_mask & 0x00FF ):
            self._gpioSet(self.i2c_handle, w_mask & 0xFF, value & 0xFF, "{}(low  byte)".format(fn_name))
        if ( w_mask & 0xFF00 ):
            self._gpioSet(self.i2c_handle, w_mask >> 8, value >> 8, "{}(high byte)".format(fn_name))

    def gpioSetDirection(self, out_mask:int, out_value:int):
        """Set the value of one or more GPIO pins and set them to out-put. 
        Args:
            out_mask(int): for every bit that is set the function will first set the bit to the value specified in out_value and then set the pin to output
            value(int): a bit-mask representing the bit values that shall be written.
        """
        self.gpioSet(w_mask=out_mask, value=out_value, fn_name="gpioSetDirection")

    def i2cGpioGet(self,r_mask:int):
        """Get the value of one or more GPIO pins. Uses the I2C interface as handle.
        Args:
            r_mask(byte): bit-mask. for every bit that is set the function will read in the value of the corresponding pin.
        Returns:
            byte: A single byte representing the up to 8 GPIOs.
        """
        return self._gpioGet(self.i2c_handle,r_mask,'i2cGpioGet')

    def i2cGpioSet(self,w_mask:int,value:int):
        """Set the value of one or more GPIO pins. Uses the I2C interface as handle.
        Args:
            w_mask(byte): for every bit that is set the function will write the value as given with parameter <val>
            value(byte): a bit-mask representing the bit values that shall be written.
        """
        self._gpioSet(self.i2c_handle,w_mask,value,'i2cGpioSet')

    def spiGpioGet(self,r_mask:int):
        """Get the value of one or more GPIO pins. Uses the SPI interface as handle.
        Args:
            r_mask(byte): bit-mask. for every bit that is set the function will read in the value of the corresponding pin.
        Returns:
            byte: A single byte representing the up to 8 GPIOs.
        """
        return self._gpioGet(self.spi_handle,r_mask,'spiGpioGet')
	
    def spiGpioSet(self,w_mask:int,value:int):
        """Set the value of one or more GPIO pins. Uses the SPI interface as handle.
        Args:
            w_mask(byte): for every bit that is set the function will write the value as given with parameter <val>
            value(byte): a bit-mask representing the bit values that shall be written.
        """
        self._gpioSet(self.spi_handle,w_mask,value,'spiGpioSet')


# to have a warning printed if you accidentially run this lib
if __name__ == "__main__":
    print ("WARNING: This is the FTDI SPI, I2C, GPIO library. Only for import in other programs.")
    # call all functions ...    
    print( "testing only ...")
    tst=FtdiMpsse(log=True,exception_on_error=True)
#    id = tst.serialNumberToChannel(b'FT66FUZNA')
#    id = tst.serialNumberToChannel(b'FT66FVUBB')
#    id = tst.serialNumberToChannel(b'FT66FVUBA')
    id = -1
    if ( id >= 0 ):
        print( "Found serial number device, channel=", id)
        tst.i2cOpen( id )
        tst.i2cClose( )
    tst.getChannelInfo()
    tst.getNumChannels()

    tst.i2cOpen(0)
    tst.spiOpen(1)

    tst.i2cTx(0x41,[0xd0])
    tst.i2cRx(0x41,1)
    tst.i2cTxRx(0x41,[0xd0],2)    
    tst.i2cGpioGet(3)
    tst.i2cGpioSet(0,0)

    v=tst.gpioGet(3)
    tst.gpioSet(3,1)
    tst.gpioSet(3,v)


    tst.spiTx([0xd0])
    tst.spiRx(10)
    tst.spiTxRx([0xd0],2)    
    tst.spiRxBits(2)
    tst.spiTxBits(0xaa,5)

    tst.spiGpioGet(3)
    tst.spiGpioSet(0,0)

    v=tst.gpioGet(0x8001)
    tst.gpioSet(0x8001,0x8001)
    tst.gpioSet(0x8001,v)


    tst.i2cClose()
    tst.spiClose()

    s = tst.getFirstError()
    while ( s ):
        print( s )
        s = tst.getFirstError()
    