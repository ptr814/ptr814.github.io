# *****************************************************************************
# * Copyright by ams OSRAM AG                                                 *
# * All rights are reserved.                                                  *
# *                                                                           *
# * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
# * THE SOFTWARE.                                                             *
# *                                                                           *
# * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
# * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
# * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
# * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
# * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
# * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
# * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES LOSS OF USE,      *
# * DATA, OR PROFITS OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
# * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
# * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
# * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
# *****************************************************************************
"""
This is an abstraction for TOF bootloader over I2C or SPI communication with register IO.
It was verified with bedwell (TMF882X) but should also work with all other TOF devices.
Some devices (e.g. TMF8701, TMF8801, TMF8805) may need to unlock the device to allow 
for these bootloader commands to work.

------------------------------------------------------------------------------------
I2C:

HW_W command:
I2C-TX:   ->  <slave-addr-W> <0x08> <0x81> <0x08> <32-Addr-0>.. <32-Addr-3> <32-Value0>..<32-Value3> <CRC> 

HW_R command:
I2C-TX:   ->  <slave-addr-W> <0x08> <0x80> <0x04> <32-Addr-0>.. <32-Addr-3> <CRC> 
I2C_TX_RX:->  <slave-addr-W> <0x08> <slave-addr-R>
          <-                                      <0x00> <0x04> <32-Value0>..<32-Value3> <CRC>

I2C_RX: not supported by bootloader protocol -> raises a runtime error
          
------------------------------------------------------------------------------------
SPI:

HW_W command:
SPI-TX:   ->  <W-Cmd> <0x08> <W-Dummy-0> <W-Dummy-1>... <0x81> <0x08> <32-Addr-0>.. <32-Addr-3> <32-Value0>..<32-Value3> <CRC>

HW_R command:
SPI_TX:   ->  <W-Cmd> <0x08> <W-Dummy-0> <W-Dummy-1>... <0x80> <0x04> <32-Addr-0>.. <32-Addr-3> <CRC>
SPI_TX_RX:->  <R-Cmd> <0x08> <R-Dummy-0> <R-Dummy-1>...
          <-                                            <0x00> <0x04> <32-Value0>..<32-Value3> <CRC>

SPI_RX: not supported by bootloader protocol -> raises a runtime error
      
"""

from aos_com.ic_com import IcCom
from aos_com.hal_register_io import HalRegisterIo
from aos_com.spi_hal_register_io import SpiHalRegisterIo
from aos_com.i2c_hal_register_io import I2cHalRegisterIo

class BlHalRegisterIo(HalRegisterIo):

    # Version log 
    # 1.0 first working version
    VERSION = 1.0 

    BL_CMD_STAT_REG_ADDR = 0x08
    BL_LEN_REG_ADDR = 0x09
    BL_CMD_HW_R = 0x80
    BL_CMD_HW_W = 0x81
    BL_ADDR_LEN = 4         # HW_R and HW_W have always 4 bytes register address
    BL_DATA_LEN = 4
    BL_MAX_RETRIES = 100    # how often to read-back (wait is dominated by IO -> e.g. min of 2ms for each retry with FTDI)

    def __init__(self,ic_com:IcCom,dev_addr:int=-1,spi_mode:int=-1,cmd_wr:int=SpiHalRegisterIo.WR_CMD, cmd_rd:int=SpiHalRegisterIo.RD_CMD, dummy_wr:int=SpiHalRegisterIo.DUMMY_WR, dummy_rd:int=SpiHalRegisterIo.DUMMY_RD, dummy:int=SpiHalRegisterIo.DUMMY, checksum:bool=False ):
        """
        Constructor. Either a valid I2C slave address must be given or a valid spi mode. If both are valid, I2C is choosen.
        Args:
            ic_com (IcCom): a class to be used for communication
            dev_addr(int): 7-bit device address if in I2C mode (else leave at -1)
            spi_mode(int): spi mode (0,1,2,3) if in SPI mode (else leave at -1)
            cmd_wr(int): byte to initiate a write to the register address 
            cmd_rd(int): byte to initiate a read from the register address 
            dummy_wr(int): number of dummy bytes at write after register address 
            dummy_rd(int): number of dummy bytes at read after register address (skipping this amount of bytes from the received data)
            dummy(int): number of dummy bytes at read-only after the chip-select is low
            checksum(bool): if bootloader commands should add a checksum byte (Bedwell and predecessors). Frenel do not use this. 
        """
        self.retries = self.BL_MAX_RETRIES
        self.checksum = checksum
        if checksum:
            self.BL_OVERHEAD = 3         # number of bytes overhead: 3 == status, len, (optional crc)
        else:
            self.BL_OVERHEAD = 2         # number of bytes overhead: 2 == status, len, 
        super().__init__(ic_com=ic_com)
        if dev_addr > 0 and dev_addr <= 0x7F:
            self.hal = I2cHalRegisterIo( ic_com=ic_com, dev_addr = dev_addr)
        elif spi_mode >= 0 and spi_mode <= 3:
            self.hal = SpiHalRegisterIo( ic_com=ic_com, spi_mode=spi_mode, cmd_wr=cmd_wr, cmd_rd=cmd_rd, dummy_wr=dummy_wr, dummy_rd=dummy_rd, dummy=dummy)
        else:
            raise RuntimeError("Neither valid i2c device address nor valid spi mode was specified. Specify one.")

    def __del__(self):
        """Cleanup."""
        pass

    def _isI2c(self):
        """Function to find out if we are using I2C == return True, or SPI == return False"""
        if isinstance(self.hal, I2cHalRegisterIo) or issubclass(self.hal.__class__, I2cHalRegisterIo):
            return True
        elif isinstance(self.hal, SpiHalRegisterIo) or issubclass(self.hal.__class__, SpiHalRegisterIo):
            return False
        else:
            raise RuntimeError("Only I2C or SPI are supported for register access via bootloader.")


    # -----------------------------------------------------------------------------------        
    # functions ---------------------------------------------------------------------
    # -----------------------------------------------------------------------------------
    def _computeBootloaderChecksum(self, data:list) -> int:
        """Compute the bootloader checksum over an array.
        Args:
            data (list): The array to compute the checksum over
        Returns:
            int: the checksum
        """
        return 0xff ^ sum(data) & 0xff
    
    def open(self, speed:int=1000000) -> int:
        """Open an interface.    """
        if self._isI2c():
            return self.com.i2cOpen( i2c_speed=speed ) 
        else:
            return self.com.spiOpen(spi_speed=speed, spi_mode=self.hal.spi_mode)

    def close(self) -> int:
        """ Function to close an interface. """
        if self._isI2c():
            return self.com.i2cClose( ) 
        else:
            return self.com.spiClose( )
            
    def _txPrepare(self,txaddr,txdata):
        """Function to build the transmit data string
        Args:
            txaddr: the 4-byte address for accessing any register or memory on the device. Must be a list or
              bytearray in the correct endianess ordering.
            txdata: 0-bytes or 4-bytes data value. If 0-bytes this is a read request. the 4-bytes must be a 
            list or bytearray in the correct endianess ordering.   
        Return:
            list for address, list for data for transmit
        """
        real_txaddr = [ self.BL_CMD_STAT_REG_ADDR]                          # txaddr is always the bootloader register 0x08
        if len(txdata) == 0: 
            real_txdata = [ self.BL_CMD_HW_R , self.BL_ADDR_LEN ]
        elif len(txdata) == 4:
            real_txdata = [ self.BL_CMD_HW_W, self.BL_ADDR_LEN + self.BL_DATA_LEN ]
        else:
            assert False, "Bootloader HW_W has 8 bytes payload, HW_R has 4 bytes payload"
        real_txdata = real_txdata + self._convertToList( txaddr, "txaddr") + self._convertToList(txdata, "txdata") # real txdata is the bootloader protocol including the 4-byte address and for a write the 4-byte data
        if self.checksum:
            real_txdata.append( self._computeBootloaderChecksum(real_txdata))    
        return real_txaddr, real_txdata

    def _rxInterpret(self,rxdata):
        """Function checks that received data is a valid an completed bootloader read.
        Strips away the status, len and crc.
        Args:
            rxdata: should be 7 (6-without checksum) bytes read from the device
        Returns:
            data the 4 bytes representing the raw value if read was successfull (self.bootloader_status is 0), 
            else a bytearray b'\x00\x00\x00\x00' and self.bootloader_status is non-zero in this case
        """
        assert len(rxdata) == self.BL_OVERHEAD + self.BL_DATA_LEN, "Bootloader HW_R must always read 7(6) bytes"
        data = self._convertToList(rxdata,"rxdata")
        self.bootloader_status = data[0]
        if self.bootloader_status == 0:
            if self.checksum:
                data = data[ 2: -1]                                         # strip away the status, len and crc: <status> <len> .data. <crc>
            else:
                data = data[ 2: ]                                           # strip away the status, len : <status> <len> .data. 
            data = bytearray(data)
        else:
            data = bytearray(self.BL_DATA_LEN)
        return data

    def tx(self,txaddr,txdata) -> int:
        """Function to transmit given bytes via the selected HAL (I2C or SPI)
        Args:
            txaddr: the 4-byte address for accessing any register or memory on the device. Must be a list or
              bytearray in the correct endianess ordering.
            txdata: 0-bytes or 4-bytes data value. If 0-bytes this is a read request. the 4-bytes must be a 
            list or bytearray in the correct endianess ordering.   
        Return:
            status of transmit
        """
        real_txaddr, real_txdata = self._txPrepare(txaddr,txdata)
        return self.hal.tx( real_txaddr, real_txdata )

    def rx(self,rx_size) -> bytearray:
        """Function to receive bytes via SPI. 
        Args:
            rx_size: number of bytes to read (bootloader header and footer bytes will be added for reading and removed
            before returning the result)
        Return:
            bytearray of 4 bytes representing the raw read value
        """
        raise RuntimeError("Bootloader has no rx only")

    def txRx(self,txaddr,rx_size) -> bytearray:
        """Function to transmit and receive bytes. 
        txaddr: the 4-byte address for accessing any register or memory on the device. Must be a list or
              bytearray in the correct endianess ordering.
        rx_size: must be 4 
        Return:
            bytearray of 4 bytes representing the raw read value
        """
        retries = self.retries
        assert rx_size == 4, "Bootloader HW_R can only read 4 bytes"
        real_txaddr, real_txdata = self._txPrepare(txaddr,[])
        self.bootloader_status =self.BL_CMD_HW_R                 # new communication
        while retries > 0 and self.bootloader_status == self.BL_CMD_HW_R:
            status = self.hal.tx( real_txaddr, real_txdata)  # first transmit the <0x80> <0x04> <Addr0>..<Addr3> <crc> == setup addr
            assert status == self.com._OK, "Bootloader, low-level Communication for tx failed with {}".format( status )
            # 2nd receive the    <0x00> <0x04> <data0>..<data3> (optional <crc> )
            rxdata = self.hal.txRx( [self.BL_CMD_STAT_REG_ADDR], rx_size + self.BL_OVERHEAD )         # always read the 4 bytes data, but also the 3 bytes bootloader protocol overhead
            # _rxInterpret(..) does also update self.bootloader_status
            data = self._rxInterpret( rxdata )
            retries -= 1
        assert self.bootloader_status == 0, "Bootloader failed at HW_R status = {} expected 0".format(self.bootloader_status)
        return data



if __name__ == "__main__":
    print( "This is only for including in other files")
