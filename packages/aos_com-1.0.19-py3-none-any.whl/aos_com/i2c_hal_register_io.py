# *****************************************************************************
# * Copyright by ams OSRAM AG                                                 *
# * All rights are reserved.                                                  *
# *                                                                           *
# * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
# * THE SOFTWARE.                                                             *
# *                                                                           *
# * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
# * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
# * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
# * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
# * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
# * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
# * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES LOSS OF USE,      *
# * DATA, OR PROFITS OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
# * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
# * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
# * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
# *****************************************************************************
"""
This is an abstraction for I2C communication with register IO. I2C would not 
need that, but SPI, UART and bootloader protocol need it.
"""

from aos_com.ic_com import IcCom
from aos_com.hal_register_io import HalRegisterIo

class I2cHalRegisterIo(HalRegisterIo):

    # Version log 
    # 1.0 first working version
    VERSION = 1.0

    def __init__(self, ic_com:IcCom, dev_addr:int ):
        """
        Constructor 
        Args:
            ic_com (IcCom): a class to be used for communication
        """
        super().__init__(ic_com=ic_com)
        self.dev_addr = dev_addr

    def __del__(self):
        """Cleanup."""
        pass

    # -----------------------------------------------------------------------------------        
    # functions ---------------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    def open(self, speed:int=1000000) -> int:
        """Open an I2C interface.        """
        return self.com.i2cOpen( i2c_speed = speed ) 

    def close(self) -> int:
        """ Function to close a I2C interface. """
        return self.com.i2cClose( )

    def tx(self,txaddr,txdata) -> int:
        """Function to transmit given bytes on I2C """
        txaddr = self._convertToList(txaddr, "txaddr")
        txdata = self._convertToList(txdata, "txdata")
        toTx = txaddr + txdata
        return self.com.i2cTx( self.dev_addr, toTx )

    def rx(self,rx_size:int) -> bytearray:
        """Function to receive bytes via I2C. """
        return self.com.i2cRx( self.dev_addr, rx_size )

    def txRx(self,txaddr:list,rx_size:int) -> bytearray:
        """Function to transmit and receive bytes via I2C. """
        txaddr = self._convertToList(txaddr, "txaddr")
        return self.com.i2cTxRx( self.dev_addr, txaddr, rx_size)
    

if __name__ == "__main__":
    print( "This is only for including in other files")
