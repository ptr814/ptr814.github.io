# *****************************************************************************
# * Copyright by ams OSRAM AG                                                 *
# * All rights are reserved.                                                  *
# *                                                                           *
# * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
# * THE SOFTWARE.                                                             *
# *                                                                           *
# * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
# * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
# * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
# * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
# * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
# * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
# * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES LOSS OF USE,      *
# * DATA, OR PROFITS OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
# * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
# * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
# * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
# *****************************************************************************
"""
This is test class for communication with ICs. 
This is a more advanced version of the IcComMirror. 
It can do wider addresses for larger address ranges (e.g. 16-bit addressing)
and it can be configured for big or little endian addressing. 
Data is always organised as bytes so it will be written as you transmit it on
I2C/SPI. I.e. first byte goes to the address that was specified, next goes
to address+1, etc.
"""

from aos_com.ic_com import IcCom
from aos_com.ic_com_mirror_flex import IcComMirrorFlex

class IcComBlMirrorFlex(IcComMirrorFlex):

    # Version log 
    # 1.0 first working version
    VERSION = 1.0

    def __init__(self, log=False, exception_on_error=True, pattern_start:int=17, pattern_step:int=3, memory_size:int=256, addr_width:int=1, addr_endian='little', spi_cmd=1, spi_dummy_wr=0, spi_dummy_rd=0, spi_dummy=0, checksum=False ):
        """
        Constructor, default is to not produce exceptions, just log the errors
        Args:
            spi_cmd: how many bytes the command has
            spi_dummy_wr: how many bytes to skip in a write
            spi_dummy_rd: how many bytes to skip in a read (in addition to the spi_dummy_wr)
            log (TYPE, optional): Print messages. Defaults to False.
            exception_on_error (TYPE, optional): Raise an exception in error case, if false only log error. Defaults to False.
            pattern_start (int, optional): Start byte to fill the memory that is used as mirror. Defaults to 17.
            pattern_step (int, optional): Value that is added for filling the memory for each byte. Defaults to 0x03.
            memory_size (int, optional): How big the mirror shall be. Defaults to 256. For 16-bit addressing use e.g. 4096.
            addr_width_in_bytes (int, optional): How many bytes to use for addressing. Defaults to 1. With 1 you can address
            up to 256 bytes of memory. If you want to emulate 16-bit addressing use e.g. 4096 for memory size and set this to 2. 
            addr_endian (str, optional): either big or little for address endianess. Defaults to little.
        """
        super().__init__(log,exception_on_error,pattern_start,pattern_step,memory_size,addr_width,addr_endian,spi_cmd,spi_dummy_wr,spi_dummy_rd,spi_dummy)
        self.checksum=checksum

    def __del__(self):
        """Cleanup."""
        super().__del__()


    # -----------------------------------------------------------------------------------        
    # I2C functions ---------------------------------------------------------------------
    # -----------------------------------------------------------------------------------

            
    def i2cTx(self,devaddr:int,tx:list) -> int:
        """Function to transmit given bytes on I2C """
        if self.checksum:
            toTx = tx[3:-1]      # remove Reg-addr, CMD, len, and the last-byte=CRC    
        else:
            toTx = tx[3:]        # remove Reg-addr, CMD, len    
        return super()._txFunc( toTx, "i2cTx" )

    def i2cRx(self,devaddr:int,rx_size:int) -> bytearray:
        """Function to receive bytes via I2C. """
        if self.checksum:
            return bytearray( [0]*2 ) + super()._rxFunc(rx_size-3, "i2cRx" ) + bytearray([0])
        else:
            return bytearray( [0]*2 ) + super()._rxFunc(rx_size-2, "i2cRx" )

    def i2cTxRx(self,devaddr:int,tx:list,rx_size:int) -> bytearray:
        """Function to transmit and receive bytes via I2C. 
            BL HW_R: first transmitted 0x80 0x04 <addr0>..<addr3> CRC, was sent with i2cTx == setup address, 
        """
        if self.checksum:
            assert 7 == rx_size, "BL readback has STAT LEN DATA0 DATA1 DATA2 DATA3 CRC "
            # add STAT, len, and the last-byte=CRC 
            return bytearray( [0,4] + list(self._rxFunc( 4, "i2cTxRx")) + [0])
        else:
            assert 6 == rx_size, "BL readback has STAT LEN DATA0 DATA1 DATA2 DATA3 "
            # add STAT, len
            return bytearray( [0,4] + list(self._rxFunc( 4, "i2cTxRx")))
    

    # -----------------------------------------------------------------------------------        
    # SPI functions ---------------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    def spiRx(self,rx_size:int) -> bytearray:
        """Function to receive the given number of bytes
        Args:
            rx_size(int): The number of bytes to receive.
            lsb_first(bool, optional): Bit order shall be little endian or big endian. The default is False = big endian.
        Returns:
            bytearray: Array of received bytes.
        """
        assert False, "BL cannot have read-only"
        return bytearray(0)     # return extended array

    def spiTx(self,tx:bytearray) -> int:
        """Function to transmit several bytes via SPI.
        Args:
            tx(list): byte list to transmit.
            lsb_first(bool, optional): If the FTDI should transmit in big-endian or little endian mode. The default is False (=big endian mode).
        Returns:
            int: status: 0 == ok, else error
        """
        if self.checksum:
            toTx = tx[self.spi_cmd + 1 + self.spi_dummy_wr + 2 : -1]    # remove spi cmd, BL-CMD_REG-ADDR, Dummy_wr, BL-CMD, BL_LEN, ... CRC 
        else:
            toTx = tx[self.spi_cmd + 1 + self.spi_dummy_wr + 2 :]       # remove spi cmd, BL-CMD_REG-ADDR, Dummy_wr, BL-CMD, BL_LEN, ...  
        self._txFunc( toTx, "spiTx" )
        return self._OK

    def spiTxRx(self,tx:bytearray,rx_size:int) -> bytearray:
        """Function to transmit and receive bytes. the function will extend the transmit list with 0 to match the receive length 
        if there are more bytes to receive than to transmit. the function will extend the receive bytearray
        with additionally read in bytes if the transmit length is greater than the receive length.
        Args:
            tx(list): list of bytes to transmit.
            rx_size(int): number of bytes to receive.
            lsb_first(bool, optional): If the FTDI should transmit in big-endian or little endian mode. The default is False (=big endian mode).
        Returns:
            bytearray: bytes received from the device.
        """
        if self.checksum:
            txing = self.spi_cmd + 1 + self.spi_dummy_rd  # <r-CMD> <0x08> <dummy_rd>.. 
            toTx = tx[self.spi_cmd + 1 + self.spi_dummy_rd + 2 : -1]    # cut out address part
            assert toTx == [] 
            # self._txFunc(toTx, "spiTxRx")
            assert rx_size == txing + 4 + 3, "BL must always read 4 bytes"  # <0x81> <0x04> <value0>..<value3> <crc>
            toRx = 4
            data = [0]*(txing + 2)                 # 2 bytes prespan for data
            data = bytearray(data) 
            return data + self._rxFunc(toRx,"spiTxRx") + bytearray([0])    # add <crc>        
        else:
            txing = self.spi_cmd + 1 + self.spi_dummy_rd  # <r-CMD> <0x08> <dummy_rd>.. 
            toTx = tx[self.spi_cmd + 1 + self.spi_dummy_rd + 2 : ]    # cut out address part
            assert toTx == [] 
            # self._txFunc(toTx, "spiTxRx")
            assert rx_size == txing + 4 + 2, "BL must always read 4 bytes"  # <0x81> <0x04> <value0>..<value3>
            toRx = 4
            data = [0]*(txing + 2)                 # 2 bytes prespan for data
            data = bytearray(data) 
            return data + self._rxFunc(toRx,"spiTxRx")           


# this is a test class - usefull for simple test of programs
if __name__ == "__main__":
    com = IcComBlMirrorFlex(memory_size=4*1024, addr_width=2,addr_endian='big')
    com.i2cOpen()
    com.i2cTx(0x11,[0x1, 0x12,  0x34,0x56,0x78,0x9a])
    com.i2cTx(0x11,[0x1, 0x12])
    assert [0x34,0x56,0x78,0x9a] == list( com.i2cRx(0x11,4) )
    fifo_addr = [(com.memory_size-1)//256, (com.memory_size-1)%256]
    com.i2cTx(0x11,fifo_addr+[1,2,3,4,5,6,7,8])
    assert com._reg_addr == com.memory_size-1, "Addr pointer stays at at {}".format(com.memory_size-1)
    assert com._buffer[com.memory_size-1] == 8, "last written value should be read back"
    assert [8,8,8,8] == list(com.i2cRx(0x11,4)), "Fifo read always same value from last address"
    com.i2cClose()
    

