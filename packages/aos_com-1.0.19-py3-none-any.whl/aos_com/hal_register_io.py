# *****************************************************************************
# * Copyright by ams OSRAM AG                                                 *
# * All rights are reserved.                                                  *
# *                                                                           *
# * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
# * THE SOFTWARE.                                                             *
# *                                                                           *
# * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
# * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
# * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
# * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
# * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
# * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
# * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES LOSS OF USE,      *
# * DATA, OR PROFITS OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
# * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
# * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
# * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
# *****************************************************************************
"""
This is an abstraction for communication with register IO. I2C would not 
need that, but SPI, UART and bootloader protocol need it.
"""

from aos_com.ic_com import IcCom

class HalRegisterIo:

    # Version log 
    # 1.0 first working version
    VERSION = 1.0

    def __init__(self, ic_com:IcCom ):
        """
        Constructor, default is to not produce exceptions, just log the errors
        Args:
            ic_com (IcCom): a class to be used for communication
        """
        self.com = ic_com

    def __del__(self):
        """Cleanup."""
        pass

    # -----------------------------------------------------------------------------------        
    # functions ---------------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    def open(self, speed:int=1000000) -> int:
        """Open an interface.        """
        return self.com._ERROR_NOT_IMPLEMENTED 

    def close(self) -> int:
        """ Function to close an interface. """
        return self.com._ERROR_NOT_IMPLEMENTED
            
    def _convertToList( self, toConvert, name:str ) -> list:
        """Function to convert from bytes, bytearray or int to list
        Args:
            toTx: element to be converted to list
            name: name of element (to be printed in case of an error)
        Returns:
            list 
        """
        assert type(toConvert) == list or type(toConvert) == bytearray or type(toConvert) == bytes or ( type(toConvert) == int and toConvert < 256 ), "{} must either be a list or can be represented in a single byte".format(name)            
        if type(toConvert) != list:
            if type(toConvert) == bytearray or type(toConvert) == bytes:
                toConvert = list(toConvert)
            else:
                toConvert = [ toConvert ]
        return toConvert

    def tx(self,txaddr,txdata) -> int:
        """Function to transmit given bytes on <HW> """
        return self.com._ERROR_NOT_IMPLEMENTED

    def rx(self,rx_size:int) -> bytearray:
        """Function to receive bytes on HW """
        return self.com._ERROR_NOT_IMPLEMENTED

    def txRx(self,txaddr:list,rx_size:int) -> bytearray:
        """Function to transmit and receive bytes on <HW>. """
        return bytearray(0)
    
# this is a test class - usefull for simple test of programs
if __name__ == "__main__":
    print( "This class is as base class for I2C, SPI or UART transport for registerIo")
