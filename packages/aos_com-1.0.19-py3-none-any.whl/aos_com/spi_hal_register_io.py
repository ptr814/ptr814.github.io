# *****************************************************************************
# * Copyright by ams OSRAM AG                                                 *
# * All rights are reserved.                                                  *
# *                                                                           *
# * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
# * THE SOFTWARE.                                                             *
# *                                                                           *
# * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
# * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
# * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
# * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
# * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
# * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
# * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES LOSS OF USE,      *
# * DATA, OR PROFITS OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
# * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
# * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
# * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
# *****************************************************************************
"""
This is an abstraction for SPI communication with register IO.

--- == don't care (MISO = do not interpret, MOSI = transmit 0)

SPI-TX:
MOSI   ->  <W-Cmd> <Addr-0> <Addr-1> <Addr-2> <W-Dummy-0> <W-Dummy-1><WData0> <WData1>....
MISO   <-  -------------------------------------------------------------------------------

SPI_TX_RX:
MOSI   ->  <R-Cmd> <Addr-0> <Addr-1> <Addr-2> <R-Dummy-0> <R-Dummy-1>---------------------- 
MIDO   <-  ----------------------------------------------------------<RData0> <RData1> ....

SPI_RX:
MOSI   ->  <Dummy-0> <Dummy-1>----------------------------------------------------------- 
MISO   <-  -------------------<RData0> <RData1> ...

"""

from aos_com.ic_com import IcCom
from aos_com.hal_register_io import HalRegisterIo

class SpiHalRegisterIo(HalRegisterIo):

    # Version log 
    # 1.0 first working version
    VERSION = 1.0
    WR_CMD = 0x2
    RD_CMD = 0x3
    DUMMY_WR = 0
    DUMMY_RD = 1
    DUMMY = 0

    def __init__(self, ic_com:IcCom, spi_mode:int,cmd_wr:int=WR_CMD, cmd_rd:int=RD_CMD,dummy_wr:int=DUMMY_WR, dummy_rd:int=DUMMY_RD, dummy:int=DUMMY ):
        """
        Constructor 
        Args:
            ic_com (IcCom): a class to be used for communication
            spi_mode(int): spi mode (0,1,2,3)
            cmd_wr(int): byte to initiate a write to the register address 
            cmd_rd(int): byte to initiate a read from the register address 
            dummy_wr(int): number of dummy bytes at write after register address 
            dummy_rd(int): number of dummy bytes at read after register address (skipping this amount of bytes from the received data)
            dummy(int): number of dummy bytes at read-only after the chip-select is low 
        """
        super().__init__(ic_com=ic_com)
        assert 0 <= spi_mode and 4 > spi_mode, "SPI mode can only be 0,1,2,3, but is {}".format(spi_mode)
        self.spi_mode = spi_mode
        self.cmd_wr = [cmd_wr]      
        self.cmd_rd = [cmd_rd]
        self.dummy_wr = [0]*dummy_wr    
        self.dummy_rd =  [0]*dummy_rd
        self.dummy = [0]*dummy

    def __del__(self):
        """Cleanup."""
        pass

    # -----------------------------------------------------------------------------------        
    # functions ---------------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    def open(self, speed:int=1000000) -> int:
        """Open a spi interface. for ftdi mpsse DBUS3 is CS active low  """
        return self.com.spiOpen( spi_speed=speed, spi_mode=self.spi_mode )

    def close(self) -> int:
        """ Function to close a SPI interface. """
        return self.com.spiClose( )
            
    def tx(self,txaddr,txdata) -> int:
        """Function to transmit given bytes SPI """
        txaddr = self.cmd_wr + self._convertToList(txaddr, "txaddr") + self.dummy_wr     # add dummy bytes
        txdata = self._convertToList(txdata, "txdata")
        toTx = txaddr + txdata
        return self.com.spiTx(toTx )

    def rx(self,rx_size:int) -> bytearray:
        """Function to receive bytes via SPI. """
        toRx = len(self.dummy) + rx_size
        data = list( self.com.spiRx( toRx ) )
        data = data[len(self.dummy):]    # skip first dummy_rd bytes
        return bytearray(data)

    def txRx(self,txaddr:list,rx_size:int) -> bytearray:
        """Function to transmit and receive bytes via SPI. """
        toTx = self.cmd_rd + self._convertToList(txaddr, "txaddr") + self.dummy_rd     # add dummy bytes
        padding = len(toTx)
        toRx = padding + rx_size
        data = list( self.com.spiTxRx(toTx, toRx) )
        # status_byte = data[padding-1]                           # last byte before real data is aka status_byte
        data = data[ padding : ]                                # cut away cmd, addr, dummy bytes
        return bytearray(data)

if __name__ == "__main__":
    print( "This is only for including in other files")
