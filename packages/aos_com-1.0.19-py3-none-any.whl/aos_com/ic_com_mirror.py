# *****************************************************************************
# * Copyright by ams OSRAM AG                                                 *
# * All rights are reserved.                                                  *
# *                                                                           *
# * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
# * THE SOFTWARE.                                                             *
# *                                                                           *
# * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
# * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
# * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
# * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
# * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
# * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
# * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES LOSS OF USE,      *
# * DATA, OR PROFITS OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
# * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
# * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
# * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
# *****************************************************************************
"""
This is test class for communication with ICs. 
It supports I2C, SPI and GPIOs.
One typical example we have is the FTDI_MPSSE class.
"""


from aos_com.ic_com import IcCom

class IcComMirror(IcCom):

    # Version log 
    # 1.0 first working version
    VERSION = 1.0
    
    def __init__(self, log=False, exception_on_error=True, pattern_start:int=17, pattern_step:int=3 ):
        """
        Constructor, default is to not produce exceptions, just log the errors
        Args:
            log (TYPE, optional): Print messages. Defaults to False.
            exception_on_error (TYPE, optional): Raise an exception in error case, if false only log error. Defaults to False.
            enable_pin (int, optional): bit-mask defining the enable pin for gpioGet, gpioSet. Defaults to 0x01.
            interrupt_pin (int, optional): bit-mask defining the interrupt pin for gpioGet, gpioSet. Defaults to 0x02.
        """
        super().__init__(log,exception_on_error)
        self._reg_addr = 0
        self._buffer = [0xff & (pattern_start + pattern_step*x) for x in range(256)]     # write some pattern to not just have uninit or all 0s

    def __del__(self):
        """Cleanup."""
        super().__del__()

    # -----------------------------------------------------------------------------------        
    # I2C functions ---------------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    def i2cOpen(self, i2c_speed:int=1000000) -> int:
        """Open an I2C interface.        """
        fn_name = "i2cOpen"
        status = self._OK
        self._log(fn_name)
        return status 

    def i2cClose(self) -> int:
        """ Function to close a I2C interface. """
        fn_name = "i2cClose"
        status = self._OK
        self._log(fn_name)
        return status 
    
    def i2cTx(self,devaddr:int,tx:list) -> int:
        """Function to transmit given bytes on I2C """
        fn_name = "i2cTx"
        status = self._OK
        self._reg_addr = tx[0]
        assert self._reg_addr <= 0xff and self._reg_addr >= 0, "I2C allows only 256 registers for write"
        for _i in range(len(tx)-1):
            self._buffer[self._reg_addr] = tx[_i+1]                         # write to buffer
            self._reg_addr += 1                                             # increment address buffer
            if self._reg_addr > 0xff:
                self._reg_addr = 0xff
        self._log(fn_name)
        return status 

    def i2cRx(self,devaddr:int,rx_size:int) -> bytearray:
        """Function to receive bytes via I2C. """
        fn_name = "i2cRx"
        status = self._OK
        _rx = []
        assert self._reg_addr <= 0xff and self._reg_addr >= 0, "I2C allows only 256 registers for read"
        for _i in range(rx_size):
            _rx = _rx + [self._buffer[self._reg_addr]]                        # read from buffer
            self._reg_addr += 1                                             # increment address buffer
            if self._reg_addr > 0xff:
                self._reg_addr = 0xff
        self._log(fn_name)
        return bytearray( _rx )

    def i2cTxRx(self,devaddr:int,tx:list,rx_size:int) -> bytearray:
        """Function to transmit and receive bytes via I2C. """
        fn_name = "i2cTxRx"
        status = self._OK
        self._log(fn_name)
        self.i2cTx(devaddr,tx)
        return self.i2cRx(devaddr,rx_size)

# this is a test class - usefull for simple test of programs
if __name__ == "__main__":
    com = IcComMirror()
    com.i2cOpen()
    com.i2cTx(0x33,[12,34,56])
    com.i2cTx(0x33,[12])
    assert [34,56] == list( com.i2cRx(0x33,2) )
    com.i2cTx(0x11,[255,1,2,3,4])
    assert com._reg_addr == 255, "Addr pointer stays at at 0xff"
    assert com._buffer[255] == 4, "last written value should be read back"
    assert [4,4,4,4] == list(com.i2cRx(0x11,4)), "Fifo read always same value from last address"
    com.i2cClose()
    

