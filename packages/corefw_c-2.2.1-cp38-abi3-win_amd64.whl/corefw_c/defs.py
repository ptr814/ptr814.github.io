# *****************************************************************************
# * Copyright © 2024 ams-OSRAM AG                                             *
# * All rights are reserved.                                                  *
# *                                                                           *
# * FOR FULL LICENSE TEXT SEE LICENSE.TXT                                     *
# *****************************************************************************

"""Various definitions"""

import dataclasses
import enum
import typing


@dataclasses.dataclass
class DeviceInfo:
    """Contains information of a discovered Core FW device.

    Attributes:
        name: The name of the device,
        serial_number: The serial number of the device.
        interface: The interface string to use to connect to the device.
        vid: The USB Vendor ID of the device.
        pid: The USB Product ID of the device.
    """

    name: str
    serial_number: str
    interface: str
    vid: int
    pid: int


class HardwarePlatformType(enum.IntEnum):
    """Represents a Core FW hardware platform type."""

    UNKNOWN = 0  # : Unknown hardware platform type
    UNICOM = 1   # : Unicom (STM32F4) hardware platform type
    NORDIC = 2   # : Nordic (nRF5) hardware platform type
    EVM_H5 = 3   # : EVM-H5 (STM32H5) hardware platform type


@dataclasses.dataclass
class FirmwareInfo:  # pylint: disable=too-many-instance-attributes
    """Contains information about the firmware running on a connected Core FW device.

    Attributes:
        application_name: The name of the application.
        firmware_version: The version of the firmware.
        hardware_revision: The revision of the hardware.
        model_number: The mode number.
        serial_number: The serial number.
        core_fw_version: The version of the underlying Core FW.
        hardware_platform_type: The hardware platform type. If the hardware platform type is known, this attribute is
            set to an corefw_c.defs.HardwarePlatformType value. Otherwise, it is set to the raw integer value of the
            hardware platform type.
        hardware_platform_variant: The hardware platform variant.
    """

    application_name: str
    firmware_version: str
    hardware_revision: str
    model_number: str
    serial_number: str
    core_fw_version: str
    hardware_platform_type: typing.Union[HardwarePlatformType, int]
    hardware_platform_variant: int


class SpiMode(enum.IntEnum):
    """Represents an SPI mode."""

    PHASE_1EDGE_POL_LOW = 0   # : Phase: first edge, polarity: low
    PHASE_1EDGE_POL_HIGH = 1  # : Phase: first edge, polarity: high
    PHASE_2EDGE_POL_LOW = 2   # : Phase: second edge, polarity: low
    PHASE_2EDGE_POL_HIGH = 3  # : Phase: second edge, polarity: high


class SpiFirstBit(enum.IntEnum):
    """Represents an SPI bit order."""

    MSB = 0  # : First bit is the most significant bit
    LSB = 1  # : First bit is the least significant bit


class I3cErrorCode(enum.IntEnum):
    """Represents an I3C-specific error code."""

    NONE = 0  # : No error
    CE0 = 1  # : Controller detected an illegally formatted CCC
    CE1 = 2  # : Controller detected that transmitted data on the bus differs from the expectation
    CE2 = 3  # : Controller detected that broadcast address 7'h7E has been NACKed
    CE3 = 4  # : Controller detected that new controller did not drive the bus after controller role handoff
    TE0 = 5  # : Target detected an invalid broadcast address
    TE1 = 6  # : Target detected an invalid CCC code
    TE2 = 7  # : Target detected a parity error during a write data
    TE3 = 8  # : Target detected a parity error on assigned address during dynamic address arbitration
    TE4 = 9  # : Target detected 7'h7E missing after restart during dynamic address assignment procedure
    TE5 = 10  # : Target detected an illegally formatted CCC
    TE6 = 11  # : Target detected that transmitted data on the bus differs from the expectation
    DATA_HAND_OFF = 12  # : I3C data error during controller-role hand-off process
    DATA_NACK = 13  # : I3C data not acknowledged error
    ADDRESS_NACK = 14  # : I3C address not acknowledged error
    COVR = 15  # : I3C S FIFO over-run or C FIFO under-run error
    DOVR = 16  # : I3C Rx FIFO over-run or Tx FIFO under-run error
    STALL = 17  # : I3C SCL stall error
    DMA = 18  # : DMA transfer error
    TIMEOUT = 19  # : Timeout error
    DMA_PARAM = 20  # : DMA parameter error
    INVALID_PARAM = 21  # : Invalid parameters error
    SIZE = 22  # : I3C size management error
    NOT_ALLOWED = 23  # : I3C operation is not allowed
    DYNAMIC_ADDR = 24  # : I3C dynamic address error
    UNKNOWN = 255  # : Unknown I3C error

    @property
    def description(self):
        """A friendly descriptive string for the error code."""

        descriptions = {
            self.NONE: "no error",
            self.CE0: "controller detected an illegally formatted CCC",
            self.CE1: "controller detected that transmitted data on the bus differs from the expectation",
            self.CE2: "controller detected that broadcast address 7'h7E has been NACKed",
            self.CE3: "controller detected that new controller did not drive the bus after controller role handoff",
            self.TE0: "target detected an invalid broadcast address",
            self.TE1: "target detected an invalid CCC code",
            self.TE2: "target detected a parity error during a write data",
            self.TE3: "target detected a parity error on assigned address during dynamic address arbitration",
            self.TE4: "target detected 7'h7E missing after restart during dynamic address assignment procedure",
            self.TE5: "target detected an illegally formatted CCC",
            self.TE6: "target detected that transmitted data on the bus differs from the expectation",
            self.DATA_HAND_OFF: "I3C data error during controller-role hand-off process",
            self.DATA_NACK: "I3C data not acknowledged error",
            self.ADDRESS_NACK: "I3C address not acknowledged error",
            self.COVR: "I3C S FIFO over-run or C FIFO under-run error",
            self.DOVR: "I3C Rx FIFO over-run or Tx FIFO under-run error",
            self.STALL: "I3C SCL stall error",
            self.DMA: "DMA transfer error",
            self.TIMEOUT: "timeout error",
            self.DMA_PARAM: "DMA parameter error",
            self.INVALID_PARAM: "invalid parameters error",
            self.SIZE: "I3C size management error",
            self.NOT_ALLOWED: "I3C operation is not allowed",
            self.DYNAMIC_ADDR: "I3C dynamic address error",
            self.UNKNOWN: "unknown I3C error",
        }
        return descriptions[self]


class I3cError(Exception):
    """Represents an I3C-specific error that occurred.

    Attributes:
        error_code: The corresponding I3C-specific error code. If the error code is known, this attribute is set to an
            corefw_c.defs.I3cErrorCode value. Otherwise, it is set to the raw integer value of the error code."""

    def __init__(self, error_code: typing.Union[I3cErrorCode, int]):
        try:
            self.error_code = I3cErrorCode(error_code)
        except ValueError:
            self.error_code = error_code
        super().__init__(self.error_code)

    def __str__(self):
        if isinstance(self.error_code, I3cErrorCode):
            return f"I3C_ERROR_{self.error_code.name}: {self.error_code.description}"
        return f"I3C error {self.error_code}"


class PioMode(enum.IntEnum):
    """Represents a pin mode."""

    INPUT_TRIG_NONE = 0     # : Input pin, no interrupt enabled
    INPUT_TRIG_RISING = 1   # : Input pin, interrupt on rising edge enabled
    INPUT_TRIG_FALLING = 2  # : Input pin, interrupt on falling edge enabled
    INPUT_TRIG_BOTH = 3     # : Input pin, interrupt on both edges enabled
    OUTPUT_TYPE_PP = 4      # : Push-pull output pin
    OUTPUT_TYPE_OD = 5      # : Open drain output pin


class PioPull(enum.IntEnum):
    """Represents a pull resistor configuration."""

    NONE = 0  # : No pull resistors
    UP = 1    # : Pull-up resistor
    DOWN = 2  # : Pull-down resistor


class PioState(enum.IntEnum):
    """Represents a pin state."""

    RESET = 0   # : Reset state (0)
    SET = 1     # : Set state (1)
    TOGGLE = 2  # : Toggle pin


class ErrorCode(enum.IntEnum):
    """Represents an error code used by the Core FW and the Core FW C client."""

    SUCCESS = 0              # : Operation was successful
    PERMISSION = 1           # : Operation is not permitted
    MESSAGE = 2              # : Message is invalid
    MESSAGE_SIZE = 3         # : Message has the wrong size
    POINTER = 4              # : Pointer is invalid
    ACCESS = 5               # : Access is denied
    ARGUMENT = 6             # : Argument is invalid
    SIZE = 7                 # : An argument has the wrong size
    NOT_SUPPORTED = 8        # : Function is not supported or not implemented
    TIMEOUT = 9              # : Operation timed out
    CHECKSUM = 10            # : Checksum comparison failed
    OVERFLOW = 11            # : Data overflow occurred
    EVENT = 12               # : Getting or setting an event failed
    INTERRUPT = 13           # : Getting or setting an interrupt failed
    TIMER_ACCESS = 14        # : Accessing the timer peripheral failed
    LED_ACCESS = 15          # : Accessing the LED peripheral failed
    TEMP_SENSOR_ACCESS = 16  # : Accessing the temperature sensor failed
    DATA_TRANSFER = 17       # : Communication error occurred
    FIFO = 18                # : FIFO operation failed
    OVER_TEMP = 19           # : Over-temperature detected
    IDENTIFICATION = 20      # : Sensor identification failed
    COM_INTERFACE = 21       # : Generic communication interface error
    SYNCHRONIZATION = 22     # : Synchronization error occurred
    PROTOCOL = 23            # : Generic protocol error occurred
    MEMORY = 24              # : Memory allocation error occurred
    THREAD = 25              # : Thread handling operation failed
    SPI = 26                 # : Accessing the SPI peripheral failed
    DAC_ACCESS = 27          # : Accessing the DAC peripheral failed
    I2C = 28                 # : Accessing the I2C peripheral failed
    NO_DATA = 29             # : No data available
    SYSTEM_CONFIG = 30       # : System configuration failed
    USB_ACCESS = 31          # : Accessing the USB peripheral failed
    ADC_ACCESS = 32          # : Accessing the ADC peripheral failed
    SENSOR_CONFIG = 33       # : Sensor configuration failed
    SATURATION = 34          # : Saturation detected
    MUTEX = 35               # : Mutex handling operation filed
    ACCELEROMETER = 36       # : Accessing the accelerometer failed
    CONFIG = 37              # : Software component is unusable due to incomplete or incorrect configuration
    BLE = 38                 # : BLE stack handling operation failed
    FILE = 39                # : File handling operation failed
    DATA = 40                # : Internal data inconsistency detected
    BUSY = 41                # : Module is busy
    I3C = 42                 # : Accessing the I3C peripheral failed

    @property
    def description(self):
        """A friendly descriptive string for the error code."""
        descriptions = {
            self.SUCCESS: "operation was successful",
            self.PERMISSION: "operation is not permitted",
            self.MESSAGE: "message is invalid",
            self.MESSAGE_SIZE: "message has the wrong size",
            self.POINTER: "pointer is invalid",
            self.ACCESS: "access is denied",
            self.ARGUMENT: "argument is invalid",
            self.SIZE: "an argument has the wrong size",
            self.NOT_SUPPORTED: "function is not supported or not implemented",
            self.TIMEOUT: "operation timed out",
            self.CHECKSUM: "checksum comparison failed",
            self.OVERFLOW: "data overflow occurred",
            self.EVENT: "getting or setting an event failed",
            self.INTERRUPT: "getting or setting an interrupt failed",
            self.TIMER_ACCESS: "accessing the timer peripheral failed",
            self.LED_ACCESS: "accessing the LED peripheral failed",
            self.TEMP_SENSOR_ACCESS: "accessing the temperature sensor failed",
            self.DATA_TRANSFER: "communication error occurred",
            self.FIFO: "FIFO operation failed",
            self.OVER_TEMP: "over-temperature detected",
            self.IDENTIFICATION: "sensor identification failed",
            self.COM_INTERFACE: "generic communication interface error",
            self.SYNCHRONIZATION: "synchronization error occurred",
            self.PROTOCOL: "generic protocol error occurred",
            self.MEMORY: "memory allocation error occurred",
            self.THREAD: "thread handling operation failed",
            self.SPI: "accessing the SPI peripheral failed",
            self.DAC_ACCESS: "accessing the DAC peripheral failed",
            self.I2C: "accessing the I2C peripheral failed",
            self.NO_DATA: "no data available",
            self.SYSTEM_CONFIG: "system configuration failed",
            self.USB_ACCESS: "accessing the USB peripheral failed",
            self.ADC_ACCESS: "accessing the ADC peripheral failed",
            self.SENSOR_CONFIG: "sensor configuration failed",
            self.SATURATION: "saturation detected",
            self.MUTEX: "mutex handling operation filed",
            self.ACCELEROMETER: "accessing the accelerometer failed",
            self.CONFIG: "software component is unusable due to incomplete or incorrect configuration",
            self.BLE: "BLE stack handling operation failed",
            self.FILE: "file handling operation failed",
            self.DATA: "internal data inconsistency detected",
            self.BUSY: "module is busy",
            self.I3C: "accessing the I3C peripheral failed",
        }
        return descriptions[self]


class Error(Exception):
    """Represents an error that occurred in the Core FW or the Core FW C client.

    Attributes:
        message: The error message as string.
        error_code: The corresponding error code. If the error code is known, this attribute is set to an
            corefw_c.defs.ErrorCode value. Otherwise, it is set to the raw integer value of the error code."""

    def __init__(self, message: str, error_code: typing.Union[ErrorCode, int]):
        self.message = message
        try:
            self.error_code = ErrorCode(error_code)
        except ValueError:
            self.error_code = error_code
        super().__init__(self.message, self.error_code)

    def __str__(self):
        if isinstance(self.error_code, ErrorCode):
            return f"{self.message} (ERR_{self.error_code.name}: {self.error_code.description})"
        return f"{self.message} (error code {self.error_code})"
