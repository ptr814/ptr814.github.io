# *****************************************************************************
# * Copyright © 2024 ams-OSRAM AG                                             *
# * All rights are reserved.                                                  *
# *                                                                           *
# * FOR FULL LICENSE TEXT SEE LICENSE.TXT                                     *
# *****************************************************************************

"""EVM-H5-specific definitions"""

import enum


class I2cId(enum.IntEnum):
    """Represents an I2C interface of the EVM-H5 board."""

    MAIN = 0       # : Primary interface
    SECONDARY = 1  # : Secondary interface


class SpiId(enum.IntEnum):
    """Represents an SPI interface of the EVM-H5 board."""

    MAIN = 0       # : Primary interface
    SECONDARY = 1  # : Secondary interface


class I3cId(enum.IntEnum):
    """Represents an I3C interface of the EVM-H5 board."""

    MAIN = 0       # : Primary interface
    SECONDARY = 1  # : Secondary interface


class PioId(enum.IntEnum):
    """Represents a pin of the EVM-H5 board."""

    USER_BTN = 0    # : USER BUTTON
    STAT_LED = 1    # : STAT_LED
    IXC1_SCL = 2    # : I2C1/I3C1 SCL
    IXC1_SDA = 3    # : I2C1/I3C1 SDA
    IXC2_SCL = 4    # : I2C2_SCL
    IXC2_SDA = 5    # : I2C2_SDA
    SPI1_NSS = 6    # : SPI1 NSS
    SPI1_SCK = 7    # : SPI1 SCK
    SPI1_MOSI = 8   # : SPI1 MOSI
    SPI1_MISO = 9   # : SPI1 MISO
    SPI2_NSS = 10   # : SPI2 NSS
    SPI2_SCK = 11   # : SPI2 SCK
    SPI2_MOSI = 12  # : SPI2 MOSI
    SPI2_MISO = 13  # : SPI2 MISO
    GPIO0 = 14      # : GPIO0
    GPIO1 = 15      # : GPIO1
    GPIO2 = 16      # : GPIO2
    GPIO3 = 17      # : GPIO3
    UART_TX = 18    # : UART_TX
    UART_RX = 19    # : UART_RX


class PwmId(enum.IntEnum):
    """Represents a PWM output of the EVM-H5 board."""

    GPIO1 = 0    # : PWM channel 0
    GPIO2 = 1    # : PWM channel 1
    UART_RX = 2  # : PWM channel 2
