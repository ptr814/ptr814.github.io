"""
This is the entrypoint of the package when executed as a module.
It implements a CLI tool for accessing the CoreFW C API.
"""
import sys
import argparse
from typing import Optional
from importlib.metadata import version

import corefw_c

ERROR_CODE = 1
corefw_version = version('corefw_c')


class CoreFwCli:
    """Class for the Command Line Interface (CLI)"""

    def run(self) -> int:
        """
        Executes the CLI tool

        Returns:
            0 - success
            otherwise error
        """

        parser = argparse.ArgumentParser(prog="corefw_c",
                                         description="CoreFW C CLI")

        parser.add_argument(
            "--version",
            dest="version",
            action="store_true",
            help="show version information and exit",
        )

        # sub command parsers
        subparsers = parser.add_subparsers()

        #######################################################################
        # list parser
        parser_list = subparsers.add_parser(
            "list",
            description="List connected devices",
        )
        parser_list.add_argument(
            "-n",
            "--name",
            metavar="NAME",
            type=str,
            default=None,
            help="List devices with filtered device name",
        )
        parser_list.add_argument(
            "-v",
            "--vid",
            metavar="VID",
            type=str,
            default=None,
            help="List devices with filtered USB VID",
        )
        parser_list.add_argument(
            "-p",
            "--pid",
            metavar="PID",
            type=str,
            default=None,
            help="List devices with filtered USB PID",
        )
        parser_list.add_argument(
            "-s",
            "--serial",
            metavar="SERIAL",
            type=str,
            default=None,
            help="List devices with filtered serial number",
        )

        parser_list.set_defaults(func=self.cmd_list)

        #######################################################################
        # info parser
        parser_info = subparsers.add_parser(
            "info",
            description="Detailed information of the device",
        )
        parser_info.add_argument(
            "address",
            metavar="ADDRESS",
            type=str,
            help="Address of the device. Use 'COMx' to connect to a normal firmware.",
        )
        parser_info.set_defaults(func=self.cmd_info)

        #######################################################################
        # update parser
        parser_update = subparsers.add_parser(
            "update",
            description="Updates the firmware of the device or starts the bootloader only",
        )
        parser_update.add_argument(
            "address",
            metavar="ADDRESS",
            type=str,
            help="Address of the device. Use 'COMx' to connect to a normal firmware or use 'DFU' for devices already in bootloader mode. A specific device can be selected via DFU:<serial_number>.",
        )
        parser_update.add_argument(
            "-f",
            "--file",
            type=str,
            help="Path to the firmware update file",
        )
        parser_update.add_argument(
            "-b",
            "--bootloader",
            action="store_true",
            default=False,
            help="Starts the bootloader only",
        )
        parser_update.add_argument(
            "-a",
            "--abort",
            action="store_true",
            default=False,
            help="Jumps back to the firmware if possible",
        )
        parser_update.set_defaults(func=self.cmd_update)

        args = parser.parse_args()

        if len(sys.argv) == 1:
            parser.print_help(sys.stdout)
            return 0

        if args.version:
            print(f"{corefw_version}")
            return 0

        error = args.func(args)  # call subcommand function
        return error

    @staticmethod
    def cmd_list(args) -> int:
        """List sub command: Gets device information

        Args:
            args: Argument object from the info subparser, has the following members:
                vid: Filter for USB VID.
                pid: Filter for USB PID.
                name: Name of the device.
                serial: Serial number of the device.

        Returns:
            0 - success, otherwise error
        """
        error = 0
        try:
            kwargs = dict()
            if args.pid:
                if args.pid.startswith("0x"):
                    kwargs['pid'] = int(args.pid[2:], 16)
                else:
                    kwargs['pid'] = int(args.pid)
            if args.vid:
                if args.vid.startswith("0x"):
                    kwargs['vid'] = int(args.vid[2:], 16)
                else:
                    kwargs['vid'] = int(args.vid)

            if args.name:
                kwargs['name'] = args.name
            if args.serial:
                kwargs['serial_number'] = args.serial
            device_list = corefw_c.CoreFw.list_devices(**kwargs)

            for device in device_list:
                print(
                    f"{device.name}: {device.interface[4:]} ({device.serial_number}, VID: {device.vid}, PID: {device.pid})")
            if not device_list:
                print("No devices found")

        except Exception as ex:  # pylint: disable=broad-except
            print(f"Error while listing connected devices: {repr(ex)}",
                  file=sys.stderr)
            error = ERROR_CODE

        return error

    @staticmethod
    def cmd_info(args) -> int:  # pylint: disable=too-many-locals,too-many-branches,too-many-statements
        """Info sub command: Gets device information

        Args:
            args: Argument object from the info subparser, has the following members:
                address: Address of the device

        Returns:
            0 - success, otherwise error
        """
        error = 0

        print(
            f"Information of device with address {args.address}"
        )
        con = None
        con = corefw_c.CoreFw("COM:" + args.address)
        try:
            con.connect()
            dev_info = con.firmware_info

            # Application name
            print(f"\tDevice name:\t {dev_info.application_name}")

            # Serial number
            print(f"\tSerial number:\t {dev_info.serial_number}")

            # FW version
            print(f"\tFW version:\t {dev_info.firmware_version}")

            # Hardware platform
            print(f"\tHW platform:\t {dev_info.hardware_platform_type} [{dev_info.hardware_platform_variant}]")

            # Hardware version
            print(f"\tHW version:\t {dev_info.hardware_revision}")

            # Model number
            print(f"\tModel number:\t {dev_info.model_number}")

            con.disconnect()

        except Exception as ex:  # pylint: disable=broad-except
            print(
                f"Error while getting device information of device {args.address}: {ex!r}",
                file=sys.stderr)
            error = ERROR_CODE

        return error

    @staticmethod
    def cmd_update(args) -> int:
        """Update sub command: Updates a firmware or starts the bootloader only

        Args:
            args: Argument object from the update subparser, has the following members:
                address: Address of the device
                file: update file
                bootloader: starts the bootloader only
                abort: Tries to start the firmware

        Returns:
            0 - success, otherwise error
        """
        def print_progress(msg: str, percent: Optional[int]):
            backspace = False
            progress_message = msg
            if percent is not None:
                progress_message += f": {percent}%"
                if 100 != percent:
                    sys.stdout.write('\x1b[1A')  # cursor up one line
                    sys.stdout.write('\x1b[2K')  # delete last line
            print(progress_message)

        error = 0
        try:

            if len(list(filter(None, [args.file, args.bootloader, args.abort]))) != 1:
                raise ValueError(
                    "Exactly one of the arguments bootloader, abort or file must be set"
                )

            if args.file:
                if args.address.startswith("DFU"):
                    print(f"Starting firmware update of device with address {args.address} (Bootloader mode)")

                    kwargs = dict()
                    kwargs['callback'] = print_progress
                    kwargs['dfu_file'] = args.file
                    if args.address.startswith("DFU:"):
                        kwargs['serial_number'] = args.address[len("DFU:"):]
                    corefw_c.CoreFw.update_firmware_in_bootloader(**kwargs)

                    # TODO The address of the firmware may change and there is no unique way to find the right address.
                    output_suffix = ""
                else:
                    print(f"Starting firmware update of device with address {args.address}")

                    con = corefw_c.CoreFw("COM:" + args.address)
                    con.connect()
                    con.update_firmware(args.file, 4000, print_progress)
                    app_name = con.firmware_info.application_name
                    app_version = con.firmware_info.firmware_version
                    con.disconnect()
                    output_suffix = f" '{app_name}' with version '{app_version}'"

                print(f"Updated successfully to application firmware{output_suffix}")

            elif args.bootloader:
                print(f"Starts bootloader of device with address {args.address}")
                fw = corefw_c.CoreFw("COM:" + args.address)
                fw.connect()
                fw.enter_bootloader()
                print("Bootloader started")

            elif args.address.startswith("DFU") and args.abort:
                kwargs = dict()
                if args.address.startswith("DFU:"):
                    kwargs['serial_number'] = args.address[len("DFU:"):]
                corefw_c.CoreFw.leave_bootloader(**kwargs)
                print("Bootloader left")

        except Exception as ex:  # pylint: disable=broad-except
            print(
                f"Error while updater execution on address {args.address}: {ex!r}",
                file=sys.stderr)
            error = 1

        return error


def main() -> int:  # pylint: disable=unused-argument
    """
    The main routine. This just calls the 'CoreFW' console application class

    Returns:
        0 - success, otherwise error
    """

    corefw_cli = CoreFwCli()
    corefw_cli_result = corefw_cli.run()
    return corefw_cli_result


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(1)
